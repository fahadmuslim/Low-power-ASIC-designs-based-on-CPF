>>This folder contains all the TCFs that I got with different toggle rates for the clk in CGonly case.
>>top_CG..-used to read into RC by changing the clock toggles
>>my3_2..-used to write tcf for different cases from RC session
>>my3_CG2X-written by applying TCF from CG.tcf obtained from NCSIM on CG instance alone and then writting this tcf 
>> all TCFs written out from RC with -computed option.
