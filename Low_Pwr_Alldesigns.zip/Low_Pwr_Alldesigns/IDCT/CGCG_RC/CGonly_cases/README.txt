This folder has all the various results and cases that were tried with different toggle rates on the clks but didnt have any useful results and hence ignored!!
