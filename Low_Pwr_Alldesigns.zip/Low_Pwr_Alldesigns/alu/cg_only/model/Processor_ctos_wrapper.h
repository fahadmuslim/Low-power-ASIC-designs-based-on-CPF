// *****************************************************************************
//                         Cadence C-to-Silicon Compiler
//          Version 14.20-s101  (64 bit), build 81996 Fri, 24 Apr 2015
// 
// File created on Wed Sep  2 17:05:40 2015
// 
// The code contained herein is generated for Cadences customer and third
// parties authorized by customer.  It may be used in accordance with a
// previously executed license agreement between Cadence and that customer.
// Absolutely no disassembling, decompiling, reverse-translations or
// reverse-engineering of the generated code is allowed.
// 
//*****************************************************************************
#ifndef Processor_ctos_wrapper_P
#define Processor_ctos_wrapper_P

#include <systemc.h>

#define CTOS_TARGET_SUFFIX(ARG) CTOS_TARGET_SUFFIX_TMP(ARG)
#define CTOS_TARGET_SUFFIX_TMP(ARG) "_" #ARG


// This foreign module encapsulates the CtoS generated Verilog models
class Processor_ctos_wrapper_vlog : public ncsc_foreign_module {
    SC_HAS_PROCESS(Processor_ctos_wrapper_vlog);
  public:
    Processor_ctos_wrapper_vlog(sc_module_name name, char  const *ctosModelSuffix)
    :   ncsc_foreign_module(name),
        clk("clk"),
        reset("reset"),
        pwr_mult("pwr_mult"),
        pwr_div("pwr_div"),
        clk_gate_mult("clk_gate_mult"),
        clk_gate_div("clk_gate_div"),
        A("A"),
        B("B"),
        SEL("SEL"),
        OUTS("OUTS"),
        m_hdlName("Processor")
    {
        m_hdlName+=ctosModelSuffix;
    }
    sc_in<bool>  clk;
    sc_in<bool>  reset;
    sc_in<sc_lv<1> >  pwr_mult;
    sc_in<sc_lv<1> >  pwr_div;
    sc_in<sc_lv<1> >  clk_gate_mult;
    sc_in<sc_lv<1> >  clk_gate_div;
    sc_in<sc_lv<32> >  A;
    sc_in<sc_lv<32> >  B;
    sc_in<sc_lv<4> >  SEL;
    sc_out<sc_lv<32> >  OUTS;
    std::string m_hdlName;
    char  const *hdl_name() const
    {
        return m_hdlName.c_str();
    }
};


// This is the main module for the verification wrapper
class Processor_ctos_wrapper : public sc_module {
    SC_HAS_PROCESS(Processor_ctos_wrapper);
  public:
    Processor_ctos_wrapper(sc_module_name name, char  const *ctosDutSuffix = "", char  const *ctosRefSuffix = NULL, bool compare = false)
    :   sc_module(name),
        clk("clk"),
        reset("reset"),
        pwr_mult("pwr_mult"),
        pwr_div("pwr_div"),
        clk_gate_mult("clk_gate_mult"),
        clk_gate_div("clk_gate_div"),
        A("A"),
        B("B"),
        SEL("SEL"),
        OUTS("OUTS"),
        m_enableCompare(true),
        pwr_mult_vlog(NULL),
        pwr_div_vlog(NULL),
        clk_gate_mult_vlog(NULL),
        clk_gate_div_vlog(NULL),
        A_vlog(NULL),
        B_vlog(NULL),
        SEL_vlog(NULL),
        OUTS_vlog_dut(NULL),
        OUTS_vlog_ref(NULL),
        OUTS_cpp("OUTS_cpp"),
        m_ctos_compare(compare)
    {
        m_ctos_dut_type=modelTypeLookUp(ctosDutSuffix);
        m_ctos_ref_type=modelTypeLookUp(ctosRefSuffix);
        if (m_ctos_dut_type==ORIG) {
            m_dut_cpp=new Processor("m_dut_cpp");
            m_dut_cpp->clk(clk);
            m_dut_cpp->reset(reset);
            m_dut_cpp->pwr_mult(pwr_mult);
            m_dut_cpp->pwr_div(pwr_div);
            m_dut_cpp->clk_gate_mult(clk_gate_mult);
            m_dut_cpp->clk_gate_div(clk_gate_div);
            m_dut_cpp->A(A);
            m_dut_cpp->B(B);
            m_dut_cpp->SEL(SEL);
            m_dut_cpp->OUTS(OUTS);
            std::cout << "CtoS Verification Wrapper: Instantiating module Processor as DUT" << std::endl;
        } else {
            m_dut_vlog=new Processor_ctos_wrapper_vlog("m_dut_vlog", ctosDutSuffix);
            m_dut_vlog->clk(clk);
            m_dut_vlog->reset(reset);
            pwr_mult_vlog=new sc_signal<sc_lv<1> > ("pwr_mult_vlog");
            m_dut_vlog->pwr_mult(*pwr_mult_vlog);
            pwr_div_vlog=new sc_signal<sc_lv<1> > ("pwr_div_vlog");
            m_dut_vlog->pwr_div(*pwr_div_vlog);
            clk_gate_mult_vlog=new sc_signal<sc_lv<1> > ("clk_gate_mult_vlog");
            m_dut_vlog->clk_gate_mult(*clk_gate_mult_vlog);
            clk_gate_div_vlog=new sc_signal<sc_lv<1> > ("clk_gate_div_vlog");
            m_dut_vlog->clk_gate_div(*clk_gate_div_vlog);
            A_vlog=new sc_signal<sc_lv<32> > ("A_vlog");
            m_dut_vlog->A(*A_vlog);
            B_vlog=new sc_signal<sc_lv<32> > ("B_vlog");
            m_dut_vlog->B(*B_vlog);
            SEL_vlog=new sc_signal<sc_lv<4> > ("SEL_vlog");
            m_dut_vlog->SEL(*SEL_vlog);
            OUTS_vlog_dut=new sc_signal<sc_lv<32> > ("OUTS_vlog_dut");
            m_dut_vlog->OUTS(*OUTS_vlog_dut);
            std::cout << "CtoS Verification Wrapper: Instantiating module " << m_dut_vlog->hdl_name() << " as DUT" << std::endl;
        }
        if (m_ctos_ref_type!=UNKNOWN) {
            if (m_ctos_ref_type==ORIG) {
                m_ref_cpp=new Processor("m_ref_cpp");
                m_ref_cpp->clk(clk);
                m_ref_cpp->reset(reset);
                m_ref_cpp->pwr_mult(pwr_mult);
                m_ref_cpp->pwr_div(pwr_div);
                m_ref_cpp->clk_gate_mult(clk_gate_mult);
                m_ref_cpp->clk_gate_div(clk_gate_div);
                m_ref_cpp->A(A);
                m_ref_cpp->B(B);
                m_ref_cpp->SEL(SEL);
                m_ref_cpp->OUTS(OUTS_cpp);
                std::cout << "CtoS Verification Wrapper: Instantiating module Processor as REF" << std::endl;
            } else {
                m_ref_vlog=new Processor_ctos_wrapper_vlog("m_ref_vlog", ctosRefSuffix);
                m_ref_vlog->clk(clk);
                m_ref_vlog->reset(reset);
                if (pwr_mult_vlog==NULL) {
                    pwr_mult_vlog=new sc_signal<sc_lv<1> > ("pwr_mult_vlog");
                }
                m_ref_vlog->pwr_mult(*pwr_mult_vlog);
                if (pwr_div_vlog==NULL) {
                    pwr_div_vlog=new sc_signal<sc_lv<1> > ("pwr_div_vlog");
                }
                m_ref_vlog->pwr_div(*pwr_div_vlog);
                if (clk_gate_mult_vlog==NULL) {
                    clk_gate_mult_vlog=new sc_signal<sc_lv<1> > ("clk_gate_mult_vlog");
                }
                m_ref_vlog->clk_gate_mult(*clk_gate_mult_vlog);
                if (clk_gate_div_vlog==NULL) {
                    clk_gate_div_vlog=new sc_signal<sc_lv<1> > ("clk_gate_div_vlog");
                }
                m_ref_vlog->clk_gate_div(*clk_gate_div_vlog);
                if (A_vlog==NULL) {
                    A_vlog=new sc_signal<sc_lv<32> > ("A_vlog");
                }
                m_ref_vlog->A(*A_vlog);
                if (B_vlog==NULL) {
                    B_vlog=new sc_signal<sc_lv<32> > ("B_vlog");
                }
                m_ref_vlog->B(*B_vlog);
                if (SEL_vlog==NULL) {
                    SEL_vlog=new sc_signal<sc_lv<4> > ("SEL_vlog");
                }
                m_ref_vlog->SEL(*SEL_vlog);
                if (OUTS_vlog_ref==NULL) {
                    OUTS_vlog_ref=new sc_signal<sc_lv<32> > ("OUTS_vlog_ref");
                }
                m_ref_vlog->OUTS(*OUTS_vlog_ref);
                std::cout << "CtoS Verification Wrapper: Instantiating module " << m_ref_vlog->hdl_name() << " as REF" << std::endl;
            }
        }
        if ((((unsigned int)m_ctos_dut_type)>1U)||((m_ctos_ref_type!=UNKNOWN)&&(((unsigned int)m_ctos_ref_type)>1U))) {
            SC_METHOD(ctos_convert_input);
            sensitive << pwr_mult;
            SC_METHOD(ctos_convert_input_0);
            sensitive << pwr_div;
            SC_METHOD(ctos_convert_input_1);
            sensitive << clk_gate_mult;
            SC_METHOD(ctos_convert_input_2);
            sensitive << clk_gate_div;
            SC_METHOD(ctos_convert_input_3);
            sensitive << A;
            SC_METHOD(ctos_convert_input_4);
            sensitive << B;
            SC_METHOD(ctos_convert_input_5);
            sensitive << SEL;
            if (OUTS_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output);
                dont_initialize();
                sensitive << *OUTS_vlog_dut;
            }
        }
        if ((m_ctos_ref_type!=UNKNOWN)&&m_ctos_compare) {
            SC_METHOD(ctos_compare_outputs);
            dont_initialize();
            sensitive << OUTS;
        }
    }
    // clock clk period 3500 rise 0 fall 1750
    sc_in<bool>  clk;
    // reset reset false
    sc_in<bool>  reset;
    sc_in<bool>  pwr_mult;
    sc_in<bool>  pwr_div;
    sc_in<bool>  clk_gate_mult;
    sc_in<bool>  clk_gate_div;
    sc_in<sc_uint<32> >  A;
    sc_in<sc_uint<32> >  B;
    sc_in<sc_uint<4> >  SEL;
    sc_out<sc_uint<32> >  OUTS;
    sc_event m_ctosWrapperError;
    bool m_enableCompare;
    
    enum SimulateRTLOnlyEnum {
        Unsupported = 0,
        SimulateRTLOnly = 1
    };

  private:
    
    enum ModelTypeEnum {
        ORIG = 0,
        VLOG = 2,
        UNKNOWN = 3
    };

    sc_signal<sc_lv<1> >  *pwr_mult_vlog;
    sc_signal<sc_lv<1> >  *pwr_div_vlog;
    sc_signal<sc_lv<1> >  *clk_gate_mult_vlog;
    sc_signal<sc_lv<1> >  *clk_gate_div_vlog;
    sc_signal<sc_lv<32> >  *A_vlog;
    sc_signal<sc_lv<32> >  *B_vlog;
    sc_signal<sc_lv<4> >  *SEL_vlog;
    sc_signal<sc_lv<32> >  *OUTS_vlog_dut;
    sc_signal<sc_lv<32> >  *OUTS_vlog_ref;
    sc_signal<sc_uint<32> >  OUTS_cpp;
    ModelTypeEnum m_ctos_dut_type;
    ModelTypeEnum m_ctos_ref_type;
    bool m_ctos_compare;
    
    union {
      public:
        Processor *m_ref_cpp;
        Processor_ctos_wrapper_vlog *m_ref_vlog;
    };

    
    union {
      public:
        Processor *m_dut_cpp;
        Processor_ctos_wrapper_vlog *m_dut_vlog;
    };

    // Converts input string to enumeration
    ModelTypeEnum modelTypeLookUp(char  const *str)
    {
        if (!str) {
            return UNKNOWN;
        }
        std::string inputString = str;
        if (inputString.empty()) {
            return ORIG;
        } else {
            return VLOG;
        }
    }
    
    template <class T, class U> 
    bool ctos_check_unknown_values(T  const *dutSig, U  const &refSig, std::string  const &dutName, std::string  const &refName)
    {
        if (!(dutSig->read().is_01())) {
            std::cout << sc_time_stamp()
            	      << ": ctos_check_unknown_values encountered unknown values!"
            	      << std::endl << dutName << ": " << (dutSig->read().to_string())
            	      << std::endl << refName << ": " << refSig << std::endl;
        }
        return true;
    }
    
    template <class T> 
    void ctos_compare_output_values(T  const &dutSig, T  const &refSig, std::string  const &dutName, std::string  const &refName)
    {
        if (!(dutSig==refSig)) {
            std::cout << sc_time_stamp()
            	      << ": ctos_compare_output_values mismatch!"
            	      << std::endl << dutName << ": " << dutSig
            	      << std::endl << refName << ": " << refSig << std::endl;
            m_ctosWrapperError.notify();
        }
    }
    void ctos_convert_input()
    {
        *pwr_mult_vlog=sc_lv<1> ((pwr_mult.read()));
    }
    void ctos_convert_input_0()
    {
        *pwr_div_vlog=sc_lv<1> ((pwr_div.read()));
    }
    void ctos_convert_input_1()
    {
        *clk_gate_mult_vlog=sc_lv<1> ((clk_gate_mult.read()));
    }
    void ctos_convert_input_2()
    {
        *clk_gate_div_vlog=sc_lv<1> ((clk_gate_div.read()));
    }
    void ctos_convert_input_3()
    {
        *A_vlog=sc_lv<32> ((A.read()));
    }
    void ctos_convert_input_4()
    {
        *B_vlog=sc_lv<32> ((B.read()));
    }
    void ctos_convert_input_5()
    {
        *SEL_vlog=sc_lv<4> ((SEL.read()));
    }
    void ctos_convert_output()
    {
        OUTS=sc_uint<32>(OUTS_vlog_dut->read());
    }
    void ctos_compare_outputs()
    {}
  public:
    // Use this constructor only if your CtoS verilog model has no suffix
    Processor_ctos_wrapper(sc_module_name name, SimulateRTLOnlyEnum simulateRTLOnly)
    :   sc_module(name),
        clk("clk"),
        reset("reset"),
        pwr_mult("pwr_mult"),
        pwr_div("pwr_div"),
        clk_gate_mult("clk_gate_mult"),
        clk_gate_div("clk_gate_div"),
        A("A"),
        B("B"),
        SEL("SEL"),
        OUTS("OUTS"),
        m_enableCompare(false),
        m_ctos_compare(false)
    {
        m_ctos_dut_type=VLOG;
        m_ctos_ref_type=UNKNOWN;
        m_dut_vlog=new Processor_ctos_wrapper_vlog("m_dut_vlog", "");
        m_dut_vlog->clk(clk);
        m_dut_vlog->reset(reset);
        pwr_mult_vlog=new sc_signal<sc_lv<1> > ("pwr_mult_vlog");
        m_dut_vlog->pwr_mult(*pwr_mult_vlog);
        pwr_div_vlog=new sc_signal<sc_lv<1> > ("pwr_div_vlog");
        m_dut_vlog->pwr_div(*pwr_div_vlog);
        clk_gate_mult_vlog=new sc_signal<sc_lv<1> > ("clk_gate_mult_vlog");
        m_dut_vlog->clk_gate_mult(*clk_gate_mult_vlog);
        clk_gate_div_vlog=new sc_signal<sc_lv<1> > ("clk_gate_div_vlog");
        m_dut_vlog->clk_gate_div(*clk_gate_div_vlog);
        A_vlog=new sc_signal<sc_lv<32> > ("A_vlog");
        m_dut_vlog->A(*A_vlog);
        B_vlog=new sc_signal<sc_lv<32> > ("B_vlog");
        m_dut_vlog->B(*B_vlog);
        SEL_vlog=new sc_signal<sc_lv<4> > ("SEL_vlog");
        m_dut_vlog->SEL(*SEL_vlog);
        OUTS_vlog_dut=new sc_signal<sc_lv<32> > ("OUTS_vlog_dut");
        m_dut_vlog->OUTS(*OUTS_vlog_dut);
        std::cout << "CtoS Verification Wrapper: Instantiating RTL module " << m_dut_vlog->hdl_name() << " as DUT" << std::endl;
        SC_METHOD(ctos_convert_input);
        sensitive << pwr_mult;
        SC_METHOD(ctos_convert_input_0);
        sensitive << pwr_div;
        SC_METHOD(ctos_convert_input_1);
        sensitive << clk_gate_mult;
        SC_METHOD(ctos_convert_input_2);
        sensitive << clk_gate_div;
        SC_METHOD(ctos_convert_input_3);
        sensitive << A;
        SC_METHOD(ctos_convert_input_4);
        sensitive << B;
        SC_METHOD(ctos_convert_input_5);
        sensitive << SEL;
        SC_METHOD(ctos_convert_output);
        dont_initialize();
        sensitive << *OUTS_vlog_dut;
    }
};




    typedef Processor_ctos_wrapper Processor_ctos;
  #define PROCESSOR_CTOS_INSTANCE(INSTNAME) Processor_ctos(INSTNAME, CTOS_TARGET_SUFFIX(CTOS_MODEL), NULL, false)
  #define PROCESSOR_CTOS_COMPARE_INSTANCE(INSTNAME, REFNAME) Processor_ctos(INSTNAME, CTOS_TARGET_SUFFIX(CTOS_MODEL), REFNAME, true)
  #define PROCESSOR_CTOS_RTL_ONLY_INSTANCE(INSTNAME) Processor_ctos(INSTNAME, Processor_ctos::SimulateRTLOnly)
#endif // ifdef Processor_ctos_wrapper_P

