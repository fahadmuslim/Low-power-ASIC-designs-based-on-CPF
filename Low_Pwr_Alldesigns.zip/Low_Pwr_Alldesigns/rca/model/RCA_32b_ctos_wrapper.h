// *****************************************************************************
//                         Cadence C-to-Silicon Compiler
//          Version 14.20-s101  (64 bit), build 81996 Fri, 24 Apr 2015
// 
// File created on Wed Sep  9 17:35:53 2015
// 
// The code contained herein is generated for Cadences customer and third
// parties authorized by customer.  It may be used in accordance with a
// previously executed license agreement between Cadence and that customer.
// Absolutely no disassembling, decompiling, reverse-translations or
// reverse-engineering of the generated code is allowed.
// 
//*****************************************************************************
#ifndef RCA_32b_ctos_wrapper_P
#define RCA_32b_ctos_wrapper_P

#include <systemc.h>

#define CTOS_TARGET_SUFFIX(ARG) CTOS_TARGET_SUFFIX_TMP(ARG)
#define CTOS_TARGET_SUFFIX_TMP(ARG) "_" #ARG


// This foreign module encapsulates the CtoS generated Verilog models
class RCA_32b_ctos_wrapper_vlog : public ncsc_foreign_module {
    SC_HAS_PROCESS(RCA_32b_ctos_wrapper_vlog);
  public:
    RCA_32b_ctos_wrapper_vlog(sc_module_name name, char  const *ctosModelSuffix)
    :   ncsc_foreign_module(name),
        clk("clk"),
        reset("reset"),
        cin("cin"),
        pwr_sig("pwr_sig"),
        clk_gate("clk_gate"),
        a0("a0"),
        a1("a1"),
        a2("a2"),
        a3("a3"),
        a4("a4"),
        a5("a5"),
        a6("a6"),
        a7("a7"),
        a8("a8"),
        a9("a9"),
        a10("a10"),
        a11("a11"),
        a12("a12"),
        a13("a13"),
        a14("a14"),
        a15("a15"),
        b0("b0"),
        b1("b1"),
        b2("b2"),
        b3("b3"),
        b4("b4"),
        b5("b5"),
        b6("b6"),
        b7("b7"),
        b8("b8"),
        b9("b9"),
        b10("b10"),
        b11("b11"),
        b12("b12"),
        b13("b13"),
        b14("b14"),
        b15("b15"),
        a16("a16"),
        a17("a17"),
        a18("a18"),
        a19("a19"),
        a20("a20"),
        a21("a21"),
        a22("a22"),
        a23("a23"),
        a24("a24"),
        a25("a25"),
        a26("a26"),
        a27("a27"),
        a28("a28"),
        a29("a29"),
        a30("a30"),
        a31("a31"),
        b16("b16"),
        b17("b17"),
        b18("b18"),
        b19("b19"),
        b20("b20"),
        b21("b21"),
        b22("b22"),
        b23("b23"),
        b24("b24"),
        b25("b25"),
        b26("b26"),
        b27("b27"),
        b28("b28"),
        b29("b29"),
        b30("b30"),
        b31("b31"),
        w_flag("w_flag"),
        s0("s0"),
        s1("s1"),
        s2("s2"),
        s3("s3"),
        s4("s4"),
        s5("s5"),
        s6("s6"),
        s7("s7"),
        s8("s8"),
        s9("s9"),
        s10("s10"),
        s11("s11"),
        s12("s12"),
        s13("s13"),
        s14("s14"),
        s15("s15"),
        s16("s16"),
        s17("s17"),
        s18("s18"),
        s19("s19"),
        s20("s20"),
        s21("s21"),
        s22("s22"),
        s23("s23"),
        s24("s24"),
        s25("s25"),
        s26("s26"),
        s27("s27"),
        s28("s28"),
        s29("s29"),
        s30("s30"),
        s31("s31"),
        cout("cout"),
        m_hdlName("RCA_32b")
    {
        m_hdlName+=ctosModelSuffix;
    }
    sc_in<bool>  clk;
    sc_in<bool>  reset;
    sc_in<sc_lv<1> >  cin;
    sc_in<sc_lv<1> >  pwr_sig;
    sc_in<sc_lv<1> >  clk_gate;
    sc_in<sc_lv<1> >  a0;
    sc_in<sc_lv<1> >  a1;
    sc_in<sc_lv<1> >  a2;
    sc_in<sc_lv<1> >  a3;
    sc_in<sc_lv<1> >  a4;
    sc_in<sc_lv<1> >  a5;
    sc_in<sc_lv<1> >  a6;
    sc_in<sc_lv<1> >  a7;
    sc_in<sc_lv<1> >  a8;
    sc_in<sc_lv<1> >  a9;
    sc_in<sc_lv<1> >  a10;
    sc_in<sc_lv<1> >  a11;
    sc_in<sc_lv<1> >  a12;
    sc_in<sc_lv<1> >  a13;
    sc_in<sc_lv<1> >  a14;
    sc_in<sc_lv<1> >  a15;
    sc_in<sc_lv<1> >  b0;
    sc_in<sc_lv<1> >  b1;
    sc_in<sc_lv<1> >  b2;
    sc_in<sc_lv<1> >  b3;
    sc_in<sc_lv<1> >  b4;
    sc_in<sc_lv<1> >  b5;
    sc_in<sc_lv<1> >  b6;
    sc_in<sc_lv<1> >  b7;
    sc_in<sc_lv<1> >  b8;
    sc_in<sc_lv<1> >  b9;
    sc_in<sc_lv<1> >  b10;
    sc_in<sc_lv<1> >  b11;
    sc_in<sc_lv<1> >  b12;
    sc_in<sc_lv<1> >  b13;
    sc_in<sc_lv<1> >  b14;
    sc_in<sc_lv<1> >  b15;
    sc_in<sc_lv<1> >  a16;
    sc_in<sc_lv<1> >  a17;
    sc_in<sc_lv<1> >  a18;
    sc_in<sc_lv<1> >  a19;
    sc_in<sc_lv<1> >  a20;
    sc_in<sc_lv<1> >  a21;
    sc_in<sc_lv<1> >  a22;
    sc_in<sc_lv<1> >  a23;
    sc_in<sc_lv<1> >  a24;
    sc_in<sc_lv<1> >  a25;
    sc_in<sc_lv<1> >  a26;
    sc_in<sc_lv<1> >  a27;
    sc_in<sc_lv<1> >  a28;
    sc_in<sc_lv<1> >  a29;
    sc_in<sc_lv<1> >  a30;
    sc_in<sc_lv<1> >  a31;
    sc_in<sc_lv<1> >  b16;
    sc_in<sc_lv<1> >  b17;
    sc_in<sc_lv<1> >  b18;
    sc_in<sc_lv<1> >  b19;
    sc_in<sc_lv<1> >  b20;
    sc_in<sc_lv<1> >  b21;
    sc_in<sc_lv<1> >  b22;
    sc_in<sc_lv<1> >  b23;
    sc_in<sc_lv<1> >  b24;
    sc_in<sc_lv<1> >  b25;
    sc_in<sc_lv<1> >  b26;
    sc_in<sc_lv<1> >  b27;
    sc_in<sc_lv<1> >  b28;
    sc_in<sc_lv<1> >  b29;
    sc_in<sc_lv<1> >  b30;
    sc_in<sc_lv<1> >  b31;
    sc_out<sc_lv<1> >  w_flag;
    sc_out<sc_lv<1> >  s0;
    sc_out<sc_lv<1> >  s1;
    sc_out<sc_lv<1> >  s2;
    sc_out<sc_lv<1> >  s3;
    sc_out<sc_lv<1> >  s4;
    sc_out<sc_lv<1> >  s5;
    sc_out<sc_lv<1> >  s6;
    sc_out<sc_lv<1> >  s7;
    sc_out<sc_lv<1> >  s8;
    sc_out<sc_lv<1> >  s9;
    sc_out<sc_lv<1> >  s10;
    sc_out<sc_lv<1> >  s11;
    sc_out<sc_lv<1> >  s12;
    sc_out<sc_lv<1> >  s13;
    sc_out<sc_lv<1> >  s14;
    sc_out<sc_lv<1> >  s15;
    sc_out<sc_lv<1> >  s16;
    sc_out<sc_lv<1> >  s17;
    sc_out<sc_lv<1> >  s18;
    sc_out<sc_lv<1> >  s19;
    sc_out<sc_lv<1> >  s20;
    sc_out<sc_lv<1> >  s21;
    sc_out<sc_lv<1> >  s22;
    sc_out<sc_lv<1> >  s23;
    sc_out<sc_lv<1> >  s24;
    sc_out<sc_lv<1> >  s25;
    sc_out<sc_lv<1> >  s26;
    sc_out<sc_lv<1> >  s27;
    sc_out<sc_lv<1> >  s28;
    sc_out<sc_lv<1> >  s29;
    sc_out<sc_lv<1> >  s30;
    sc_out<sc_lv<1> >  s31;
    sc_out<sc_lv<1> >  cout;
    std::string m_hdlName;
    char  const *hdl_name() const
    {
        return m_hdlName.c_str();
    }
};


// This is the main module for the verification wrapper
class RCA_32b_ctos_wrapper : public sc_module {
    SC_HAS_PROCESS(RCA_32b_ctos_wrapper);
  public:
    RCA_32b_ctos_wrapper(sc_module_name name, char  const *ctosDutSuffix = "", char  const *ctosRefSuffix = NULL, bool compare = false)
    :   sc_module(name),
        clk("clk"),
        reset("reset"),
        cin("cin"),
        pwr_sig("pwr_sig"),
        clk_gate("clk_gate"),
        a0("a0"),
        a1("a1"),
        a2("a2"),
        a3("a3"),
        a4("a4"),
        a5("a5"),
        a6("a6"),
        a7("a7"),
        a8("a8"),
        a9("a9"),
        a10("a10"),
        a11("a11"),
        a12("a12"),
        a13("a13"),
        a14("a14"),
        a15("a15"),
        b0("b0"),
        b1("b1"),
        b2("b2"),
        b3("b3"),
        b4("b4"),
        b5("b5"),
        b6("b6"),
        b7("b7"),
        b8("b8"),
        b9("b9"),
        b10("b10"),
        b11("b11"),
        b12("b12"),
        b13("b13"),
        b14("b14"),
        b15("b15"),
        a16("a16"),
        a17("a17"),
        a18("a18"),
        a19("a19"),
        a20("a20"),
        a21("a21"),
        a22("a22"),
        a23("a23"),
        a24("a24"),
        a25("a25"),
        a26("a26"),
        a27("a27"),
        a28("a28"),
        a29("a29"),
        a30("a30"),
        a31("a31"),
        b16("b16"),
        b17("b17"),
        b18("b18"),
        b19("b19"),
        b20("b20"),
        b21("b21"),
        b22("b22"),
        b23("b23"),
        b24("b24"),
        b25("b25"),
        b26("b26"),
        b27("b27"),
        b28("b28"),
        b29("b29"),
        b30("b30"),
        b31("b31"),
        w_flag("w_flag"),
        s0("s0"),
        s1("s1"),
        s2("s2"),
        s3("s3"),
        s4("s4"),
        s5("s5"),
        s6("s6"),
        s7("s7"),
        s8("s8"),
        s9("s9"),
        s10("s10"),
        s11("s11"),
        s12("s12"),
        s13("s13"),
        s14("s14"),
        s15("s15"),
        s16("s16"),
        s17("s17"),
        s18("s18"),
        s19("s19"),
        s20("s20"),
        s21("s21"),
        s22("s22"),
        s23("s23"),
        s24("s24"),
        s25("s25"),
        s26("s26"),
        s27("s27"),
        s28("s28"),
        s29("s29"),
        s30("s30"),
        s31("s31"),
        cout("cout"),
        m_enableCompare(true),
        cin_vlog(NULL),
        pwr_sig_vlog(NULL),
        clk_gate_vlog(NULL),
        a0_vlog(NULL),
        a1_vlog(NULL),
        a2_vlog(NULL),
        a3_vlog(NULL),
        a4_vlog(NULL),
        a5_vlog(NULL),
        a6_vlog(NULL),
        a7_vlog(NULL),
        a8_vlog(NULL),
        a9_vlog(NULL),
        a10_vlog(NULL),
        a11_vlog(NULL),
        a12_vlog(NULL),
        a13_vlog(NULL),
        a14_vlog(NULL),
        a15_vlog(NULL),
        b0_vlog(NULL),
        b1_vlog(NULL),
        b2_vlog(NULL),
        b3_vlog(NULL),
        b4_vlog(NULL),
        b5_vlog(NULL),
        b6_vlog(NULL),
        b7_vlog(NULL),
        b8_vlog(NULL),
        b9_vlog(NULL),
        b10_vlog(NULL),
        b11_vlog(NULL),
        b12_vlog(NULL),
        b13_vlog(NULL),
        b14_vlog(NULL),
        b15_vlog(NULL),
        a16_vlog(NULL),
        a17_vlog(NULL),
        a18_vlog(NULL),
        a19_vlog(NULL),
        a20_vlog(NULL),
        a21_vlog(NULL),
        a22_vlog(NULL),
        a23_vlog(NULL),
        a24_vlog(NULL),
        a25_vlog(NULL),
        a26_vlog(NULL),
        a27_vlog(NULL),
        a28_vlog(NULL),
        a29_vlog(NULL),
        a30_vlog(NULL),
        a31_vlog(NULL),
        b16_vlog(NULL),
        b17_vlog(NULL),
        b18_vlog(NULL),
        b19_vlog(NULL),
        b20_vlog(NULL),
        b21_vlog(NULL),
        b22_vlog(NULL),
        b23_vlog(NULL),
        b24_vlog(NULL),
        b25_vlog(NULL),
        b26_vlog(NULL),
        b27_vlog(NULL),
        b28_vlog(NULL),
        b29_vlog(NULL),
        b30_vlog(NULL),
        b31_vlog(NULL),
        w_flag_vlog_dut(NULL),
        w_flag_vlog_ref(NULL),
        w_flag_cpp("w_flag_cpp"),
        s0_vlog_dut(NULL),
        s0_vlog_ref(NULL),
        s0_cpp("s0_cpp"),
        s1_vlog_dut(NULL),
        s1_vlog_ref(NULL),
        s1_cpp("s1_cpp"),
        s2_vlog_dut(NULL),
        s2_vlog_ref(NULL),
        s2_cpp("s2_cpp"),
        s3_vlog_dut(NULL),
        s3_vlog_ref(NULL),
        s3_cpp("s3_cpp"),
        s4_vlog_dut(NULL),
        s4_vlog_ref(NULL),
        s4_cpp("s4_cpp"),
        s5_vlog_dut(NULL),
        s5_vlog_ref(NULL),
        s5_cpp("s5_cpp"),
        s6_vlog_dut(NULL),
        s6_vlog_ref(NULL),
        s6_cpp("s6_cpp"),
        s7_vlog_dut(NULL),
        s7_vlog_ref(NULL),
        s7_cpp("s7_cpp"),
        s8_vlog_dut(NULL),
        s8_vlog_ref(NULL),
        s8_cpp("s8_cpp"),
        s9_vlog_dut(NULL),
        s9_vlog_ref(NULL),
        s9_cpp("s9_cpp"),
        s10_vlog_dut(NULL),
        s10_vlog_ref(NULL),
        s10_cpp("s10_cpp"),
        s11_vlog_dut(NULL),
        s11_vlog_ref(NULL),
        s11_cpp("s11_cpp"),
        s12_vlog_dut(NULL),
        s12_vlog_ref(NULL),
        s12_cpp("s12_cpp"),
        s13_vlog_dut(NULL),
        s13_vlog_ref(NULL),
        s13_cpp("s13_cpp"),
        s14_vlog_dut(NULL),
        s14_vlog_ref(NULL),
        s14_cpp("s14_cpp"),
        s15_vlog_dut(NULL),
        s15_vlog_ref(NULL),
        s15_cpp("s15_cpp"),
        s16_vlog_dut(NULL),
        s16_vlog_ref(NULL),
        s16_cpp("s16_cpp"),
        s17_vlog_dut(NULL),
        s17_vlog_ref(NULL),
        s17_cpp("s17_cpp"),
        s18_vlog_dut(NULL),
        s18_vlog_ref(NULL),
        s18_cpp("s18_cpp"),
        s19_vlog_dut(NULL),
        s19_vlog_ref(NULL),
        s19_cpp("s19_cpp"),
        s20_vlog_dut(NULL),
        s20_vlog_ref(NULL),
        s20_cpp("s20_cpp"),
        s21_vlog_dut(NULL),
        s21_vlog_ref(NULL),
        s21_cpp("s21_cpp"),
        s22_vlog_dut(NULL),
        s22_vlog_ref(NULL),
        s22_cpp("s22_cpp"),
        s23_vlog_dut(NULL),
        s23_vlog_ref(NULL),
        s23_cpp("s23_cpp"),
        s24_vlog_dut(NULL),
        s24_vlog_ref(NULL),
        s24_cpp("s24_cpp"),
        s25_vlog_dut(NULL),
        s25_vlog_ref(NULL),
        s25_cpp("s25_cpp"),
        s26_vlog_dut(NULL),
        s26_vlog_ref(NULL),
        s26_cpp("s26_cpp"),
        s27_vlog_dut(NULL),
        s27_vlog_ref(NULL),
        s27_cpp("s27_cpp"),
        s28_vlog_dut(NULL),
        s28_vlog_ref(NULL),
        s28_cpp("s28_cpp"),
        s29_vlog_dut(NULL),
        s29_vlog_ref(NULL),
        s29_cpp("s29_cpp"),
        s30_vlog_dut(NULL),
        s30_vlog_ref(NULL),
        s30_cpp("s30_cpp"),
        s31_vlog_dut(NULL),
        s31_vlog_ref(NULL),
        s31_cpp("s31_cpp"),
        cout_vlog_dut(NULL),
        cout_vlog_ref(NULL),
        cout_cpp("cout_cpp"),
        m_ctos_compare(compare)
    {
        m_ctos_dut_type=modelTypeLookUp(ctosDutSuffix);
        m_ctos_ref_type=modelTypeLookUp(ctosRefSuffix);
        if (m_ctos_dut_type==ORIG) {
            m_dut_cpp=new RCA_32b("m_dut_cpp");
            m_dut_cpp->clk(clk);
            m_dut_cpp->reset(reset);
            m_dut_cpp->cin(cin);
            m_dut_cpp->pwr_sig(pwr_sig);
            m_dut_cpp->clk_gate(clk_gate);
            m_dut_cpp->a0(a0);
            m_dut_cpp->a1(a1);
            m_dut_cpp->a2(a2);
            m_dut_cpp->a3(a3);
            m_dut_cpp->a4(a4);
            m_dut_cpp->a5(a5);
            m_dut_cpp->a6(a6);
            m_dut_cpp->a7(a7);
            m_dut_cpp->a8(a8);
            m_dut_cpp->a9(a9);
            m_dut_cpp->a10(a10);
            m_dut_cpp->a11(a11);
            m_dut_cpp->a12(a12);
            m_dut_cpp->a13(a13);
            m_dut_cpp->a14(a14);
            m_dut_cpp->a15(a15);
            m_dut_cpp->b0(b0);
            m_dut_cpp->b1(b1);
            m_dut_cpp->b2(b2);
            m_dut_cpp->b3(b3);
            m_dut_cpp->b4(b4);
            m_dut_cpp->b5(b5);
            m_dut_cpp->b6(b6);
            m_dut_cpp->b7(b7);
            m_dut_cpp->b8(b8);
            m_dut_cpp->b9(b9);
            m_dut_cpp->b10(b10);
            m_dut_cpp->b11(b11);
            m_dut_cpp->b12(b12);
            m_dut_cpp->b13(b13);
            m_dut_cpp->b14(b14);
            m_dut_cpp->b15(b15);
            m_dut_cpp->a16(a16);
            m_dut_cpp->a17(a17);
            m_dut_cpp->a18(a18);
            m_dut_cpp->a19(a19);
            m_dut_cpp->a20(a20);
            m_dut_cpp->a21(a21);
            m_dut_cpp->a22(a22);
            m_dut_cpp->a23(a23);
            m_dut_cpp->a24(a24);
            m_dut_cpp->a25(a25);
            m_dut_cpp->a26(a26);
            m_dut_cpp->a27(a27);
            m_dut_cpp->a28(a28);
            m_dut_cpp->a29(a29);
            m_dut_cpp->a30(a30);
            m_dut_cpp->a31(a31);
            m_dut_cpp->b16(b16);
            m_dut_cpp->b17(b17);
            m_dut_cpp->b18(b18);
            m_dut_cpp->b19(b19);
            m_dut_cpp->b20(b20);
            m_dut_cpp->b21(b21);
            m_dut_cpp->b22(b22);
            m_dut_cpp->b23(b23);
            m_dut_cpp->b24(b24);
            m_dut_cpp->b25(b25);
            m_dut_cpp->b26(b26);
            m_dut_cpp->b27(b27);
            m_dut_cpp->b28(b28);
            m_dut_cpp->b29(b29);
            m_dut_cpp->b30(b30);
            m_dut_cpp->b31(b31);
            m_dut_cpp->w_flag(w_flag);
            m_dut_cpp->s0(s0);
            m_dut_cpp->s1(s1);
            m_dut_cpp->s2(s2);
            m_dut_cpp->s3(s3);
            m_dut_cpp->s4(s4);
            m_dut_cpp->s5(s5);
            m_dut_cpp->s6(s6);
            m_dut_cpp->s7(s7);
            m_dut_cpp->s8(s8);
            m_dut_cpp->s9(s9);
            m_dut_cpp->s10(s10);
            m_dut_cpp->s11(s11);
            m_dut_cpp->s12(s12);
            m_dut_cpp->s13(s13);
            m_dut_cpp->s14(s14);
            m_dut_cpp->s15(s15);
            m_dut_cpp->s16(s16);
            m_dut_cpp->s17(s17);
            m_dut_cpp->s18(s18);
            m_dut_cpp->s19(s19);
            m_dut_cpp->s20(s20);
            m_dut_cpp->s21(s21);
            m_dut_cpp->s22(s22);
            m_dut_cpp->s23(s23);
            m_dut_cpp->s24(s24);
            m_dut_cpp->s25(s25);
            m_dut_cpp->s26(s26);
            m_dut_cpp->s27(s27);
            m_dut_cpp->s28(s28);
            m_dut_cpp->s29(s29);
            m_dut_cpp->s30(s30);
            m_dut_cpp->s31(s31);
            m_dut_cpp->cout(cout);
            std::cout << "CtoS Verification Wrapper: Instantiating module RCA_32b as DUT" << std::endl;
        } else {
            m_dut_vlog=new RCA_32b_ctos_wrapper_vlog("m_dut_vlog", ctosDutSuffix);
            m_dut_vlog->clk(clk);
            m_dut_vlog->reset(reset);
            cin_vlog=new sc_signal<sc_lv<1> > ("cin_vlog");
            m_dut_vlog->cin(*cin_vlog);
            pwr_sig_vlog=new sc_signal<sc_lv<1> > ("pwr_sig_vlog");
            m_dut_vlog->pwr_sig(*pwr_sig_vlog);
            clk_gate_vlog=new sc_signal<sc_lv<1> > ("clk_gate_vlog");
            m_dut_vlog->clk_gate(*clk_gate_vlog);
            a0_vlog=new sc_signal<sc_lv<1> > ("a0_vlog");
            m_dut_vlog->a0(*a0_vlog);
            a1_vlog=new sc_signal<sc_lv<1> > ("a1_vlog");
            m_dut_vlog->a1(*a1_vlog);
            a2_vlog=new sc_signal<sc_lv<1> > ("a2_vlog");
            m_dut_vlog->a2(*a2_vlog);
            a3_vlog=new sc_signal<sc_lv<1> > ("a3_vlog");
            m_dut_vlog->a3(*a3_vlog);
            a4_vlog=new sc_signal<sc_lv<1> > ("a4_vlog");
            m_dut_vlog->a4(*a4_vlog);
            a5_vlog=new sc_signal<sc_lv<1> > ("a5_vlog");
            m_dut_vlog->a5(*a5_vlog);
            a6_vlog=new sc_signal<sc_lv<1> > ("a6_vlog");
            m_dut_vlog->a6(*a6_vlog);
            a7_vlog=new sc_signal<sc_lv<1> > ("a7_vlog");
            m_dut_vlog->a7(*a7_vlog);
            a8_vlog=new sc_signal<sc_lv<1> > ("a8_vlog");
            m_dut_vlog->a8(*a8_vlog);
            a9_vlog=new sc_signal<sc_lv<1> > ("a9_vlog");
            m_dut_vlog->a9(*a9_vlog);
            a10_vlog=new sc_signal<sc_lv<1> > ("a10_vlog");
            m_dut_vlog->a10(*a10_vlog);
            a11_vlog=new sc_signal<sc_lv<1> > ("a11_vlog");
            m_dut_vlog->a11(*a11_vlog);
            a12_vlog=new sc_signal<sc_lv<1> > ("a12_vlog");
            m_dut_vlog->a12(*a12_vlog);
            a13_vlog=new sc_signal<sc_lv<1> > ("a13_vlog");
            m_dut_vlog->a13(*a13_vlog);
            a14_vlog=new sc_signal<sc_lv<1> > ("a14_vlog");
            m_dut_vlog->a14(*a14_vlog);
            a15_vlog=new sc_signal<sc_lv<1> > ("a15_vlog");
            m_dut_vlog->a15(*a15_vlog);
            b0_vlog=new sc_signal<sc_lv<1> > ("b0_vlog");
            m_dut_vlog->b0(*b0_vlog);
            b1_vlog=new sc_signal<sc_lv<1> > ("b1_vlog");
            m_dut_vlog->b1(*b1_vlog);
            b2_vlog=new sc_signal<sc_lv<1> > ("b2_vlog");
            m_dut_vlog->b2(*b2_vlog);
            b3_vlog=new sc_signal<sc_lv<1> > ("b3_vlog");
            m_dut_vlog->b3(*b3_vlog);
            b4_vlog=new sc_signal<sc_lv<1> > ("b4_vlog");
            m_dut_vlog->b4(*b4_vlog);
            b5_vlog=new sc_signal<sc_lv<1> > ("b5_vlog");
            m_dut_vlog->b5(*b5_vlog);
            b6_vlog=new sc_signal<sc_lv<1> > ("b6_vlog");
            m_dut_vlog->b6(*b6_vlog);
            b7_vlog=new sc_signal<sc_lv<1> > ("b7_vlog");
            m_dut_vlog->b7(*b7_vlog);
            b8_vlog=new sc_signal<sc_lv<1> > ("b8_vlog");
            m_dut_vlog->b8(*b8_vlog);
            b9_vlog=new sc_signal<sc_lv<1> > ("b9_vlog");
            m_dut_vlog->b9(*b9_vlog);
            b10_vlog=new sc_signal<sc_lv<1> > ("b10_vlog");
            m_dut_vlog->b10(*b10_vlog);
            b11_vlog=new sc_signal<sc_lv<1> > ("b11_vlog");
            m_dut_vlog->b11(*b11_vlog);
            b12_vlog=new sc_signal<sc_lv<1> > ("b12_vlog");
            m_dut_vlog->b12(*b12_vlog);
            b13_vlog=new sc_signal<sc_lv<1> > ("b13_vlog");
            m_dut_vlog->b13(*b13_vlog);
            b14_vlog=new sc_signal<sc_lv<1> > ("b14_vlog");
            m_dut_vlog->b14(*b14_vlog);
            b15_vlog=new sc_signal<sc_lv<1> > ("b15_vlog");
            m_dut_vlog->b15(*b15_vlog);
            a16_vlog=new sc_signal<sc_lv<1> > ("a16_vlog");
            m_dut_vlog->a16(*a16_vlog);
            a17_vlog=new sc_signal<sc_lv<1> > ("a17_vlog");
            m_dut_vlog->a17(*a17_vlog);
            a18_vlog=new sc_signal<sc_lv<1> > ("a18_vlog");
            m_dut_vlog->a18(*a18_vlog);
            a19_vlog=new sc_signal<sc_lv<1> > ("a19_vlog");
            m_dut_vlog->a19(*a19_vlog);
            a20_vlog=new sc_signal<sc_lv<1> > ("a20_vlog");
            m_dut_vlog->a20(*a20_vlog);
            a21_vlog=new sc_signal<sc_lv<1> > ("a21_vlog");
            m_dut_vlog->a21(*a21_vlog);
            a22_vlog=new sc_signal<sc_lv<1> > ("a22_vlog");
            m_dut_vlog->a22(*a22_vlog);
            a23_vlog=new sc_signal<sc_lv<1> > ("a23_vlog");
            m_dut_vlog->a23(*a23_vlog);
            a24_vlog=new sc_signal<sc_lv<1> > ("a24_vlog");
            m_dut_vlog->a24(*a24_vlog);
            a25_vlog=new sc_signal<sc_lv<1> > ("a25_vlog");
            m_dut_vlog->a25(*a25_vlog);
            a26_vlog=new sc_signal<sc_lv<1> > ("a26_vlog");
            m_dut_vlog->a26(*a26_vlog);
            a27_vlog=new sc_signal<sc_lv<1> > ("a27_vlog");
            m_dut_vlog->a27(*a27_vlog);
            a28_vlog=new sc_signal<sc_lv<1> > ("a28_vlog");
            m_dut_vlog->a28(*a28_vlog);
            a29_vlog=new sc_signal<sc_lv<1> > ("a29_vlog");
            m_dut_vlog->a29(*a29_vlog);
            a30_vlog=new sc_signal<sc_lv<1> > ("a30_vlog");
            m_dut_vlog->a30(*a30_vlog);
            a31_vlog=new sc_signal<sc_lv<1> > ("a31_vlog");
            m_dut_vlog->a31(*a31_vlog);
            b16_vlog=new sc_signal<sc_lv<1> > ("b16_vlog");
            m_dut_vlog->b16(*b16_vlog);
            b17_vlog=new sc_signal<sc_lv<1> > ("b17_vlog");
            m_dut_vlog->b17(*b17_vlog);
            b18_vlog=new sc_signal<sc_lv<1> > ("b18_vlog");
            m_dut_vlog->b18(*b18_vlog);
            b19_vlog=new sc_signal<sc_lv<1> > ("b19_vlog");
            m_dut_vlog->b19(*b19_vlog);
            b20_vlog=new sc_signal<sc_lv<1> > ("b20_vlog");
            m_dut_vlog->b20(*b20_vlog);
            b21_vlog=new sc_signal<sc_lv<1> > ("b21_vlog");
            m_dut_vlog->b21(*b21_vlog);
            b22_vlog=new sc_signal<sc_lv<1> > ("b22_vlog");
            m_dut_vlog->b22(*b22_vlog);
            b23_vlog=new sc_signal<sc_lv<1> > ("b23_vlog");
            m_dut_vlog->b23(*b23_vlog);
            b24_vlog=new sc_signal<sc_lv<1> > ("b24_vlog");
            m_dut_vlog->b24(*b24_vlog);
            b25_vlog=new sc_signal<sc_lv<1> > ("b25_vlog");
            m_dut_vlog->b25(*b25_vlog);
            b26_vlog=new sc_signal<sc_lv<1> > ("b26_vlog");
            m_dut_vlog->b26(*b26_vlog);
            b27_vlog=new sc_signal<sc_lv<1> > ("b27_vlog");
            m_dut_vlog->b27(*b27_vlog);
            b28_vlog=new sc_signal<sc_lv<1> > ("b28_vlog");
            m_dut_vlog->b28(*b28_vlog);
            b29_vlog=new sc_signal<sc_lv<1> > ("b29_vlog");
            m_dut_vlog->b29(*b29_vlog);
            b30_vlog=new sc_signal<sc_lv<1> > ("b30_vlog");
            m_dut_vlog->b30(*b30_vlog);
            b31_vlog=new sc_signal<sc_lv<1> > ("b31_vlog");
            m_dut_vlog->b31(*b31_vlog);
            w_flag_vlog_dut=new sc_signal<sc_lv<1> > ("w_flag_vlog_dut");
            m_dut_vlog->w_flag(*w_flag_vlog_dut);
            s0_vlog_dut=new sc_signal<sc_lv<1> > ("s0_vlog_dut");
            m_dut_vlog->s0(*s0_vlog_dut);
            s1_vlog_dut=new sc_signal<sc_lv<1> > ("s1_vlog_dut");
            m_dut_vlog->s1(*s1_vlog_dut);
            s2_vlog_dut=new sc_signal<sc_lv<1> > ("s2_vlog_dut");
            m_dut_vlog->s2(*s2_vlog_dut);
            s3_vlog_dut=new sc_signal<sc_lv<1> > ("s3_vlog_dut");
            m_dut_vlog->s3(*s3_vlog_dut);
            s4_vlog_dut=new sc_signal<sc_lv<1> > ("s4_vlog_dut");
            m_dut_vlog->s4(*s4_vlog_dut);
            s5_vlog_dut=new sc_signal<sc_lv<1> > ("s5_vlog_dut");
            m_dut_vlog->s5(*s5_vlog_dut);
            s6_vlog_dut=new sc_signal<sc_lv<1> > ("s6_vlog_dut");
            m_dut_vlog->s6(*s6_vlog_dut);
            s7_vlog_dut=new sc_signal<sc_lv<1> > ("s7_vlog_dut");
            m_dut_vlog->s7(*s7_vlog_dut);
            s8_vlog_dut=new sc_signal<sc_lv<1> > ("s8_vlog_dut");
            m_dut_vlog->s8(*s8_vlog_dut);
            s9_vlog_dut=new sc_signal<sc_lv<1> > ("s9_vlog_dut");
            m_dut_vlog->s9(*s9_vlog_dut);
            s10_vlog_dut=new sc_signal<sc_lv<1> > ("s10_vlog_dut");
            m_dut_vlog->s10(*s10_vlog_dut);
            s11_vlog_dut=new sc_signal<sc_lv<1> > ("s11_vlog_dut");
            m_dut_vlog->s11(*s11_vlog_dut);
            s12_vlog_dut=new sc_signal<sc_lv<1> > ("s12_vlog_dut");
            m_dut_vlog->s12(*s12_vlog_dut);
            s13_vlog_dut=new sc_signal<sc_lv<1> > ("s13_vlog_dut");
            m_dut_vlog->s13(*s13_vlog_dut);
            s14_vlog_dut=new sc_signal<sc_lv<1> > ("s14_vlog_dut");
            m_dut_vlog->s14(*s14_vlog_dut);
            s15_vlog_dut=new sc_signal<sc_lv<1> > ("s15_vlog_dut");
            m_dut_vlog->s15(*s15_vlog_dut);
            s16_vlog_dut=new sc_signal<sc_lv<1> > ("s16_vlog_dut");
            m_dut_vlog->s16(*s16_vlog_dut);
            s17_vlog_dut=new sc_signal<sc_lv<1> > ("s17_vlog_dut");
            m_dut_vlog->s17(*s17_vlog_dut);
            s18_vlog_dut=new sc_signal<sc_lv<1> > ("s18_vlog_dut");
            m_dut_vlog->s18(*s18_vlog_dut);
            s19_vlog_dut=new sc_signal<sc_lv<1> > ("s19_vlog_dut");
            m_dut_vlog->s19(*s19_vlog_dut);
            s20_vlog_dut=new sc_signal<sc_lv<1> > ("s20_vlog_dut");
            m_dut_vlog->s20(*s20_vlog_dut);
            s21_vlog_dut=new sc_signal<sc_lv<1> > ("s21_vlog_dut");
            m_dut_vlog->s21(*s21_vlog_dut);
            s22_vlog_dut=new sc_signal<sc_lv<1> > ("s22_vlog_dut");
            m_dut_vlog->s22(*s22_vlog_dut);
            s23_vlog_dut=new sc_signal<sc_lv<1> > ("s23_vlog_dut");
            m_dut_vlog->s23(*s23_vlog_dut);
            s24_vlog_dut=new sc_signal<sc_lv<1> > ("s24_vlog_dut");
            m_dut_vlog->s24(*s24_vlog_dut);
            s25_vlog_dut=new sc_signal<sc_lv<1> > ("s25_vlog_dut");
            m_dut_vlog->s25(*s25_vlog_dut);
            s26_vlog_dut=new sc_signal<sc_lv<1> > ("s26_vlog_dut");
            m_dut_vlog->s26(*s26_vlog_dut);
            s27_vlog_dut=new sc_signal<sc_lv<1> > ("s27_vlog_dut");
            m_dut_vlog->s27(*s27_vlog_dut);
            s28_vlog_dut=new sc_signal<sc_lv<1> > ("s28_vlog_dut");
            m_dut_vlog->s28(*s28_vlog_dut);
            s29_vlog_dut=new sc_signal<sc_lv<1> > ("s29_vlog_dut");
            m_dut_vlog->s29(*s29_vlog_dut);
            s30_vlog_dut=new sc_signal<sc_lv<1> > ("s30_vlog_dut");
            m_dut_vlog->s30(*s30_vlog_dut);
            s31_vlog_dut=new sc_signal<sc_lv<1> > ("s31_vlog_dut");
            m_dut_vlog->s31(*s31_vlog_dut);
            cout_vlog_dut=new sc_signal<sc_lv<1> > ("cout_vlog_dut");
            m_dut_vlog->cout(*cout_vlog_dut);
            std::cout << "CtoS Verification Wrapper: Instantiating module " << m_dut_vlog->hdl_name() << " as DUT" << std::endl;
        }
        if (m_ctos_ref_type!=UNKNOWN) {
            if (m_ctos_ref_type==ORIG) {
                m_ref_cpp=new RCA_32b("m_ref_cpp");
                m_ref_cpp->clk(clk);
                m_ref_cpp->reset(reset);
                m_ref_cpp->cin(cin);
                m_ref_cpp->pwr_sig(pwr_sig);
                m_ref_cpp->clk_gate(clk_gate);
                m_ref_cpp->a0(a0);
                m_ref_cpp->a1(a1);
                m_ref_cpp->a2(a2);
                m_ref_cpp->a3(a3);
                m_ref_cpp->a4(a4);
                m_ref_cpp->a5(a5);
                m_ref_cpp->a6(a6);
                m_ref_cpp->a7(a7);
                m_ref_cpp->a8(a8);
                m_ref_cpp->a9(a9);
                m_ref_cpp->a10(a10);
                m_ref_cpp->a11(a11);
                m_ref_cpp->a12(a12);
                m_ref_cpp->a13(a13);
                m_ref_cpp->a14(a14);
                m_ref_cpp->a15(a15);
                m_ref_cpp->b0(b0);
                m_ref_cpp->b1(b1);
                m_ref_cpp->b2(b2);
                m_ref_cpp->b3(b3);
                m_ref_cpp->b4(b4);
                m_ref_cpp->b5(b5);
                m_ref_cpp->b6(b6);
                m_ref_cpp->b7(b7);
                m_ref_cpp->b8(b8);
                m_ref_cpp->b9(b9);
                m_ref_cpp->b10(b10);
                m_ref_cpp->b11(b11);
                m_ref_cpp->b12(b12);
                m_ref_cpp->b13(b13);
                m_ref_cpp->b14(b14);
                m_ref_cpp->b15(b15);
                m_ref_cpp->a16(a16);
                m_ref_cpp->a17(a17);
                m_ref_cpp->a18(a18);
                m_ref_cpp->a19(a19);
                m_ref_cpp->a20(a20);
                m_ref_cpp->a21(a21);
                m_ref_cpp->a22(a22);
                m_ref_cpp->a23(a23);
                m_ref_cpp->a24(a24);
                m_ref_cpp->a25(a25);
                m_ref_cpp->a26(a26);
                m_ref_cpp->a27(a27);
                m_ref_cpp->a28(a28);
                m_ref_cpp->a29(a29);
                m_ref_cpp->a30(a30);
                m_ref_cpp->a31(a31);
                m_ref_cpp->b16(b16);
                m_ref_cpp->b17(b17);
                m_ref_cpp->b18(b18);
                m_ref_cpp->b19(b19);
                m_ref_cpp->b20(b20);
                m_ref_cpp->b21(b21);
                m_ref_cpp->b22(b22);
                m_ref_cpp->b23(b23);
                m_ref_cpp->b24(b24);
                m_ref_cpp->b25(b25);
                m_ref_cpp->b26(b26);
                m_ref_cpp->b27(b27);
                m_ref_cpp->b28(b28);
                m_ref_cpp->b29(b29);
                m_ref_cpp->b30(b30);
                m_ref_cpp->b31(b31);
                m_ref_cpp->w_flag(w_flag_cpp);
                m_ref_cpp->s0(s0_cpp);
                m_ref_cpp->s1(s1_cpp);
                m_ref_cpp->s2(s2_cpp);
                m_ref_cpp->s3(s3_cpp);
                m_ref_cpp->s4(s4_cpp);
                m_ref_cpp->s5(s5_cpp);
                m_ref_cpp->s6(s6_cpp);
                m_ref_cpp->s7(s7_cpp);
                m_ref_cpp->s8(s8_cpp);
                m_ref_cpp->s9(s9_cpp);
                m_ref_cpp->s10(s10_cpp);
                m_ref_cpp->s11(s11_cpp);
                m_ref_cpp->s12(s12_cpp);
                m_ref_cpp->s13(s13_cpp);
                m_ref_cpp->s14(s14_cpp);
                m_ref_cpp->s15(s15_cpp);
                m_ref_cpp->s16(s16_cpp);
                m_ref_cpp->s17(s17_cpp);
                m_ref_cpp->s18(s18_cpp);
                m_ref_cpp->s19(s19_cpp);
                m_ref_cpp->s20(s20_cpp);
                m_ref_cpp->s21(s21_cpp);
                m_ref_cpp->s22(s22_cpp);
                m_ref_cpp->s23(s23_cpp);
                m_ref_cpp->s24(s24_cpp);
                m_ref_cpp->s25(s25_cpp);
                m_ref_cpp->s26(s26_cpp);
                m_ref_cpp->s27(s27_cpp);
                m_ref_cpp->s28(s28_cpp);
                m_ref_cpp->s29(s29_cpp);
                m_ref_cpp->s30(s30_cpp);
                m_ref_cpp->s31(s31_cpp);
                m_ref_cpp->cout(cout_cpp);
                std::cout << "CtoS Verification Wrapper: Instantiating module RCA_32b as REF" << std::endl;
            } else {
                m_ref_vlog=new RCA_32b_ctos_wrapper_vlog("m_ref_vlog", ctosRefSuffix);
                m_ref_vlog->clk(clk);
                m_ref_vlog->reset(reset);
                if (cin_vlog==NULL) {
                    cin_vlog=new sc_signal<sc_lv<1> > ("cin_vlog");
                }
                m_ref_vlog->cin(*cin_vlog);
                if (pwr_sig_vlog==NULL) {
                    pwr_sig_vlog=new sc_signal<sc_lv<1> > ("pwr_sig_vlog");
                }
                m_ref_vlog->pwr_sig(*pwr_sig_vlog);
                if (clk_gate_vlog==NULL) {
                    clk_gate_vlog=new sc_signal<sc_lv<1> > ("clk_gate_vlog");
                }
                m_ref_vlog->clk_gate(*clk_gate_vlog);
                if (a0_vlog==NULL) {
                    a0_vlog=new sc_signal<sc_lv<1> > ("a0_vlog");
                }
                m_ref_vlog->a0(*a0_vlog);
                if (a1_vlog==NULL) {
                    a1_vlog=new sc_signal<sc_lv<1> > ("a1_vlog");
                }
                m_ref_vlog->a1(*a1_vlog);
                if (a2_vlog==NULL) {
                    a2_vlog=new sc_signal<sc_lv<1> > ("a2_vlog");
                }
                m_ref_vlog->a2(*a2_vlog);
                if (a3_vlog==NULL) {
                    a3_vlog=new sc_signal<sc_lv<1> > ("a3_vlog");
                }
                m_ref_vlog->a3(*a3_vlog);
                if (a4_vlog==NULL) {
                    a4_vlog=new sc_signal<sc_lv<1> > ("a4_vlog");
                }
                m_ref_vlog->a4(*a4_vlog);
                if (a5_vlog==NULL) {
                    a5_vlog=new sc_signal<sc_lv<1> > ("a5_vlog");
                }
                m_ref_vlog->a5(*a5_vlog);
                if (a6_vlog==NULL) {
                    a6_vlog=new sc_signal<sc_lv<1> > ("a6_vlog");
                }
                m_ref_vlog->a6(*a6_vlog);
                if (a7_vlog==NULL) {
                    a7_vlog=new sc_signal<sc_lv<1> > ("a7_vlog");
                }
                m_ref_vlog->a7(*a7_vlog);
                if (a8_vlog==NULL) {
                    a8_vlog=new sc_signal<sc_lv<1> > ("a8_vlog");
                }
                m_ref_vlog->a8(*a8_vlog);
                if (a9_vlog==NULL) {
                    a9_vlog=new sc_signal<sc_lv<1> > ("a9_vlog");
                }
                m_ref_vlog->a9(*a9_vlog);
                if (a10_vlog==NULL) {
                    a10_vlog=new sc_signal<sc_lv<1> > ("a10_vlog");
                }
                m_ref_vlog->a10(*a10_vlog);
                if (a11_vlog==NULL) {
                    a11_vlog=new sc_signal<sc_lv<1> > ("a11_vlog");
                }
                m_ref_vlog->a11(*a11_vlog);
                if (a12_vlog==NULL) {
                    a12_vlog=new sc_signal<sc_lv<1> > ("a12_vlog");
                }
                m_ref_vlog->a12(*a12_vlog);
                if (a13_vlog==NULL) {
                    a13_vlog=new sc_signal<sc_lv<1> > ("a13_vlog");
                }
                m_ref_vlog->a13(*a13_vlog);
                if (a14_vlog==NULL) {
                    a14_vlog=new sc_signal<sc_lv<1> > ("a14_vlog");
                }
                m_ref_vlog->a14(*a14_vlog);
                if (a15_vlog==NULL) {
                    a15_vlog=new sc_signal<sc_lv<1> > ("a15_vlog");
                }
                m_ref_vlog->a15(*a15_vlog);
                if (b0_vlog==NULL) {
                    b0_vlog=new sc_signal<sc_lv<1> > ("b0_vlog");
                }
                m_ref_vlog->b0(*b0_vlog);
                if (b1_vlog==NULL) {
                    b1_vlog=new sc_signal<sc_lv<1> > ("b1_vlog");
                }
                m_ref_vlog->b1(*b1_vlog);
                if (b2_vlog==NULL) {
                    b2_vlog=new sc_signal<sc_lv<1> > ("b2_vlog");
                }
                m_ref_vlog->b2(*b2_vlog);
                if (b3_vlog==NULL) {
                    b3_vlog=new sc_signal<sc_lv<1> > ("b3_vlog");
                }
                m_ref_vlog->b3(*b3_vlog);
                if (b4_vlog==NULL) {
                    b4_vlog=new sc_signal<sc_lv<1> > ("b4_vlog");
                }
                m_ref_vlog->b4(*b4_vlog);
                if (b5_vlog==NULL) {
                    b5_vlog=new sc_signal<sc_lv<1> > ("b5_vlog");
                }
                m_ref_vlog->b5(*b5_vlog);
                if (b6_vlog==NULL) {
                    b6_vlog=new sc_signal<sc_lv<1> > ("b6_vlog");
                }
                m_ref_vlog->b6(*b6_vlog);
                if (b7_vlog==NULL) {
                    b7_vlog=new sc_signal<sc_lv<1> > ("b7_vlog");
                }
                m_ref_vlog->b7(*b7_vlog);
                if (b8_vlog==NULL) {
                    b8_vlog=new sc_signal<sc_lv<1> > ("b8_vlog");
                }
                m_ref_vlog->b8(*b8_vlog);
                if (b9_vlog==NULL) {
                    b9_vlog=new sc_signal<sc_lv<1> > ("b9_vlog");
                }
                m_ref_vlog->b9(*b9_vlog);
                if (b10_vlog==NULL) {
                    b10_vlog=new sc_signal<sc_lv<1> > ("b10_vlog");
                }
                m_ref_vlog->b10(*b10_vlog);
                if (b11_vlog==NULL) {
                    b11_vlog=new sc_signal<sc_lv<1> > ("b11_vlog");
                }
                m_ref_vlog->b11(*b11_vlog);
                if (b12_vlog==NULL) {
                    b12_vlog=new sc_signal<sc_lv<1> > ("b12_vlog");
                }
                m_ref_vlog->b12(*b12_vlog);
                if (b13_vlog==NULL) {
                    b13_vlog=new sc_signal<sc_lv<1> > ("b13_vlog");
                }
                m_ref_vlog->b13(*b13_vlog);
                if (b14_vlog==NULL) {
                    b14_vlog=new sc_signal<sc_lv<1> > ("b14_vlog");
                }
                m_ref_vlog->b14(*b14_vlog);
                if (b15_vlog==NULL) {
                    b15_vlog=new sc_signal<sc_lv<1> > ("b15_vlog");
                }
                m_ref_vlog->b15(*b15_vlog);
                if (a16_vlog==NULL) {
                    a16_vlog=new sc_signal<sc_lv<1> > ("a16_vlog");
                }
                m_ref_vlog->a16(*a16_vlog);
                if (a17_vlog==NULL) {
                    a17_vlog=new sc_signal<sc_lv<1> > ("a17_vlog");
                }
                m_ref_vlog->a17(*a17_vlog);
                if (a18_vlog==NULL) {
                    a18_vlog=new sc_signal<sc_lv<1> > ("a18_vlog");
                }
                m_ref_vlog->a18(*a18_vlog);
                if (a19_vlog==NULL) {
                    a19_vlog=new sc_signal<sc_lv<1> > ("a19_vlog");
                }
                m_ref_vlog->a19(*a19_vlog);
                if (a20_vlog==NULL) {
                    a20_vlog=new sc_signal<sc_lv<1> > ("a20_vlog");
                }
                m_ref_vlog->a20(*a20_vlog);
                if (a21_vlog==NULL) {
                    a21_vlog=new sc_signal<sc_lv<1> > ("a21_vlog");
                }
                m_ref_vlog->a21(*a21_vlog);
                if (a22_vlog==NULL) {
                    a22_vlog=new sc_signal<sc_lv<1> > ("a22_vlog");
                }
                m_ref_vlog->a22(*a22_vlog);
                if (a23_vlog==NULL) {
                    a23_vlog=new sc_signal<sc_lv<1> > ("a23_vlog");
                }
                m_ref_vlog->a23(*a23_vlog);
                if (a24_vlog==NULL) {
                    a24_vlog=new sc_signal<sc_lv<1> > ("a24_vlog");
                }
                m_ref_vlog->a24(*a24_vlog);
                if (a25_vlog==NULL) {
                    a25_vlog=new sc_signal<sc_lv<1> > ("a25_vlog");
                }
                m_ref_vlog->a25(*a25_vlog);
                if (a26_vlog==NULL) {
                    a26_vlog=new sc_signal<sc_lv<1> > ("a26_vlog");
                }
                m_ref_vlog->a26(*a26_vlog);
                if (a27_vlog==NULL) {
                    a27_vlog=new sc_signal<sc_lv<1> > ("a27_vlog");
                }
                m_ref_vlog->a27(*a27_vlog);
                if (a28_vlog==NULL) {
                    a28_vlog=new sc_signal<sc_lv<1> > ("a28_vlog");
                }
                m_ref_vlog->a28(*a28_vlog);
                if (a29_vlog==NULL) {
                    a29_vlog=new sc_signal<sc_lv<1> > ("a29_vlog");
                }
                m_ref_vlog->a29(*a29_vlog);
                if (a30_vlog==NULL) {
                    a30_vlog=new sc_signal<sc_lv<1> > ("a30_vlog");
                }
                m_ref_vlog->a30(*a30_vlog);
                if (a31_vlog==NULL) {
                    a31_vlog=new sc_signal<sc_lv<1> > ("a31_vlog");
                }
                m_ref_vlog->a31(*a31_vlog);
                if (b16_vlog==NULL) {
                    b16_vlog=new sc_signal<sc_lv<1> > ("b16_vlog");
                }
                m_ref_vlog->b16(*b16_vlog);
                if (b17_vlog==NULL) {
                    b17_vlog=new sc_signal<sc_lv<1> > ("b17_vlog");
                }
                m_ref_vlog->b17(*b17_vlog);
                if (b18_vlog==NULL) {
                    b18_vlog=new sc_signal<sc_lv<1> > ("b18_vlog");
                }
                m_ref_vlog->b18(*b18_vlog);
                if (b19_vlog==NULL) {
                    b19_vlog=new sc_signal<sc_lv<1> > ("b19_vlog");
                }
                m_ref_vlog->b19(*b19_vlog);
                if (b20_vlog==NULL) {
                    b20_vlog=new sc_signal<sc_lv<1> > ("b20_vlog");
                }
                m_ref_vlog->b20(*b20_vlog);
                if (b21_vlog==NULL) {
                    b21_vlog=new sc_signal<sc_lv<1> > ("b21_vlog");
                }
                m_ref_vlog->b21(*b21_vlog);
                if (b22_vlog==NULL) {
                    b22_vlog=new sc_signal<sc_lv<1> > ("b22_vlog");
                }
                m_ref_vlog->b22(*b22_vlog);
                if (b23_vlog==NULL) {
                    b23_vlog=new sc_signal<sc_lv<1> > ("b23_vlog");
                }
                m_ref_vlog->b23(*b23_vlog);
                if (b24_vlog==NULL) {
                    b24_vlog=new sc_signal<sc_lv<1> > ("b24_vlog");
                }
                m_ref_vlog->b24(*b24_vlog);
                if (b25_vlog==NULL) {
                    b25_vlog=new sc_signal<sc_lv<1> > ("b25_vlog");
                }
                m_ref_vlog->b25(*b25_vlog);
                if (b26_vlog==NULL) {
                    b26_vlog=new sc_signal<sc_lv<1> > ("b26_vlog");
                }
                m_ref_vlog->b26(*b26_vlog);
                if (b27_vlog==NULL) {
                    b27_vlog=new sc_signal<sc_lv<1> > ("b27_vlog");
                }
                m_ref_vlog->b27(*b27_vlog);
                if (b28_vlog==NULL) {
                    b28_vlog=new sc_signal<sc_lv<1> > ("b28_vlog");
                }
                m_ref_vlog->b28(*b28_vlog);
                if (b29_vlog==NULL) {
                    b29_vlog=new sc_signal<sc_lv<1> > ("b29_vlog");
                }
                m_ref_vlog->b29(*b29_vlog);
                if (b30_vlog==NULL) {
                    b30_vlog=new sc_signal<sc_lv<1> > ("b30_vlog");
                }
                m_ref_vlog->b30(*b30_vlog);
                if (b31_vlog==NULL) {
                    b31_vlog=new sc_signal<sc_lv<1> > ("b31_vlog");
                }
                m_ref_vlog->b31(*b31_vlog);
                if (w_flag_vlog_ref==NULL) {
                    w_flag_vlog_ref=new sc_signal<sc_lv<1> > ("w_flag_vlog_ref");
                }
                m_ref_vlog->w_flag(*w_flag_vlog_ref);
                if (s0_vlog_ref==NULL) {
                    s0_vlog_ref=new sc_signal<sc_lv<1> > ("s0_vlog_ref");
                }
                m_ref_vlog->s0(*s0_vlog_ref);
                if (s1_vlog_ref==NULL) {
                    s1_vlog_ref=new sc_signal<sc_lv<1> > ("s1_vlog_ref");
                }
                m_ref_vlog->s1(*s1_vlog_ref);
                if (s2_vlog_ref==NULL) {
                    s2_vlog_ref=new sc_signal<sc_lv<1> > ("s2_vlog_ref");
                }
                m_ref_vlog->s2(*s2_vlog_ref);
                if (s3_vlog_ref==NULL) {
                    s3_vlog_ref=new sc_signal<sc_lv<1> > ("s3_vlog_ref");
                }
                m_ref_vlog->s3(*s3_vlog_ref);
                if (s4_vlog_ref==NULL) {
                    s4_vlog_ref=new sc_signal<sc_lv<1> > ("s4_vlog_ref");
                }
                m_ref_vlog->s4(*s4_vlog_ref);
                if (s5_vlog_ref==NULL) {
                    s5_vlog_ref=new sc_signal<sc_lv<1> > ("s5_vlog_ref");
                }
                m_ref_vlog->s5(*s5_vlog_ref);
                if (s6_vlog_ref==NULL) {
                    s6_vlog_ref=new sc_signal<sc_lv<1> > ("s6_vlog_ref");
                }
                m_ref_vlog->s6(*s6_vlog_ref);
                if (s7_vlog_ref==NULL) {
                    s7_vlog_ref=new sc_signal<sc_lv<1> > ("s7_vlog_ref");
                }
                m_ref_vlog->s7(*s7_vlog_ref);
                if (s8_vlog_ref==NULL) {
                    s8_vlog_ref=new sc_signal<sc_lv<1> > ("s8_vlog_ref");
                }
                m_ref_vlog->s8(*s8_vlog_ref);
                if (s9_vlog_ref==NULL) {
                    s9_vlog_ref=new sc_signal<sc_lv<1> > ("s9_vlog_ref");
                }
                m_ref_vlog->s9(*s9_vlog_ref);
                if (s10_vlog_ref==NULL) {
                    s10_vlog_ref=new sc_signal<sc_lv<1> > ("s10_vlog_ref");
                }
                m_ref_vlog->s10(*s10_vlog_ref);
                if (s11_vlog_ref==NULL) {
                    s11_vlog_ref=new sc_signal<sc_lv<1> > ("s11_vlog_ref");
                }
                m_ref_vlog->s11(*s11_vlog_ref);
                if (s12_vlog_ref==NULL) {
                    s12_vlog_ref=new sc_signal<sc_lv<1> > ("s12_vlog_ref");
                }
                m_ref_vlog->s12(*s12_vlog_ref);
                if (s13_vlog_ref==NULL) {
                    s13_vlog_ref=new sc_signal<sc_lv<1> > ("s13_vlog_ref");
                }
                m_ref_vlog->s13(*s13_vlog_ref);
                if (s14_vlog_ref==NULL) {
                    s14_vlog_ref=new sc_signal<sc_lv<1> > ("s14_vlog_ref");
                }
                m_ref_vlog->s14(*s14_vlog_ref);
                if (s15_vlog_ref==NULL) {
                    s15_vlog_ref=new sc_signal<sc_lv<1> > ("s15_vlog_ref");
                }
                m_ref_vlog->s15(*s15_vlog_ref);
                if (s16_vlog_ref==NULL) {
                    s16_vlog_ref=new sc_signal<sc_lv<1> > ("s16_vlog_ref");
                }
                m_ref_vlog->s16(*s16_vlog_ref);
                if (s17_vlog_ref==NULL) {
                    s17_vlog_ref=new sc_signal<sc_lv<1> > ("s17_vlog_ref");
                }
                m_ref_vlog->s17(*s17_vlog_ref);
                if (s18_vlog_ref==NULL) {
                    s18_vlog_ref=new sc_signal<sc_lv<1> > ("s18_vlog_ref");
                }
                m_ref_vlog->s18(*s18_vlog_ref);
                if (s19_vlog_ref==NULL) {
                    s19_vlog_ref=new sc_signal<sc_lv<1> > ("s19_vlog_ref");
                }
                m_ref_vlog->s19(*s19_vlog_ref);
                if (s20_vlog_ref==NULL) {
                    s20_vlog_ref=new sc_signal<sc_lv<1> > ("s20_vlog_ref");
                }
                m_ref_vlog->s20(*s20_vlog_ref);
                if (s21_vlog_ref==NULL) {
                    s21_vlog_ref=new sc_signal<sc_lv<1> > ("s21_vlog_ref");
                }
                m_ref_vlog->s21(*s21_vlog_ref);
                if (s22_vlog_ref==NULL) {
                    s22_vlog_ref=new sc_signal<sc_lv<1> > ("s22_vlog_ref");
                }
                m_ref_vlog->s22(*s22_vlog_ref);
                if (s23_vlog_ref==NULL) {
                    s23_vlog_ref=new sc_signal<sc_lv<1> > ("s23_vlog_ref");
                }
                m_ref_vlog->s23(*s23_vlog_ref);
                if (s24_vlog_ref==NULL) {
                    s24_vlog_ref=new sc_signal<sc_lv<1> > ("s24_vlog_ref");
                }
                m_ref_vlog->s24(*s24_vlog_ref);
                if (s25_vlog_ref==NULL) {
                    s25_vlog_ref=new sc_signal<sc_lv<1> > ("s25_vlog_ref");
                }
                m_ref_vlog->s25(*s25_vlog_ref);
                if (s26_vlog_ref==NULL) {
                    s26_vlog_ref=new sc_signal<sc_lv<1> > ("s26_vlog_ref");
                }
                m_ref_vlog->s26(*s26_vlog_ref);
                if (s27_vlog_ref==NULL) {
                    s27_vlog_ref=new sc_signal<sc_lv<1> > ("s27_vlog_ref");
                }
                m_ref_vlog->s27(*s27_vlog_ref);
                if (s28_vlog_ref==NULL) {
                    s28_vlog_ref=new sc_signal<sc_lv<1> > ("s28_vlog_ref");
                }
                m_ref_vlog->s28(*s28_vlog_ref);
                if (s29_vlog_ref==NULL) {
                    s29_vlog_ref=new sc_signal<sc_lv<1> > ("s29_vlog_ref");
                }
                m_ref_vlog->s29(*s29_vlog_ref);
                if (s30_vlog_ref==NULL) {
                    s30_vlog_ref=new sc_signal<sc_lv<1> > ("s30_vlog_ref");
                }
                m_ref_vlog->s30(*s30_vlog_ref);
                if (s31_vlog_ref==NULL) {
                    s31_vlog_ref=new sc_signal<sc_lv<1> > ("s31_vlog_ref");
                }
                m_ref_vlog->s31(*s31_vlog_ref);
                if (cout_vlog_ref==NULL) {
                    cout_vlog_ref=new sc_signal<sc_lv<1> > ("cout_vlog_ref");
                }
                m_ref_vlog->cout(*cout_vlog_ref);
                std::cout << "CtoS Verification Wrapper: Instantiating module " << m_ref_vlog->hdl_name() << " as REF" << std::endl;
            }
        }
        if ((((unsigned int)m_ctos_dut_type)>1U)||((m_ctos_ref_type!=UNKNOWN)&&(((unsigned int)m_ctos_ref_type)>1U))) {
            SC_METHOD(ctos_convert_input);
            sensitive << cin;
            SC_METHOD(ctos_convert_input_0);
            sensitive << pwr_sig;
            SC_METHOD(ctos_convert_input_1);
            sensitive << clk_gate;
            SC_METHOD(ctos_convert_input_2);
            sensitive << a0;
            SC_METHOD(ctos_convert_input_3);
            sensitive << a1;
            SC_METHOD(ctos_convert_input_4);
            sensitive << a2;
            SC_METHOD(ctos_convert_input_5);
            sensitive << a3;
            SC_METHOD(ctos_convert_input_6);
            sensitive << a4;
            SC_METHOD(ctos_convert_input_7);
            sensitive << a5;
            SC_METHOD(ctos_convert_input_8);
            sensitive << a6;
            SC_METHOD(ctos_convert_input_9);
            sensitive << a7;
            SC_METHOD(ctos_convert_input_10);
            sensitive << a8;
            SC_METHOD(ctos_convert_input_11);
            sensitive << a9;
            SC_METHOD(ctos_convert_input_12);
            sensitive << a10;
            SC_METHOD(ctos_convert_input_13);
            sensitive << a11;
            SC_METHOD(ctos_convert_input_14);
            sensitive << a12;
            SC_METHOD(ctos_convert_input_15);
            sensitive << a13;
            SC_METHOD(ctos_convert_input_16);
            sensitive << a14;
            SC_METHOD(ctos_convert_input_17);
            sensitive << a15;
            SC_METHOD(ctos_convert_input_18);
            sensitive << b0;
            SC_METHOD(ctos_convert_input_19);
            sensitive << b1;
            SC_METHOD(ctos_convert_input_20);
            sensitive << b2;
            SC_METHOD(ctos_convert_input_21);
            sensitive << b3;
            SC_METHOD(ctos_convert_input_22);
            sensitive << b4;
            SC_METHOD(ctos_convert_input_23);
            sensitive << b5;
            SC_METHOD(ctos_convert_input_24);
            sensitive << b6;
            SC_METHOD(ctos_convert_input_25);
            sensitive << b7;
            SC_METHOD(ctos_convert_input_26);
            sensitive << b8;
            SC_METHOD(ctos_convert_input_27);
            sensitive << b9;
            SC_METHOD(ctos_convert_input_28);
            sensitive << b10;
            SC_METHOD(ctos_convert_input_29);
            sensitive << b11;
            SC_METHOD(ctos_convert_input_30);
            sensitive << b12;
            SC_METHOD(ctos_convert_input_31);
            sensitive << b13;
            SC_METHOD(ctos_convert_input_32);
            sensitive << b14;
            SC_METHOD(ctos_convert_input_33);
            sensitive << b15;
            SC_METHOD(ctos_convert_input_34);
            sensitive << a16;
            SC_METHOD(ctos_convert_input_35);
            sensitive << a17;
            SC_METHOD(ctos_convert_input_36);
            sensitive << a18;
            SC_METHOD(ctos_convert_input_37);
            sensitive << a19;
            SC_METHOD(ctos_convert_input_38);
            sensitive << a20;
            SC_METHOD(ctos_convert_input_39);
            sensitive << a21;
            SC_METHOD(ctos_convert_input_40);
            sensitive << a22;
            SC_METHOD(ctos_convert_input_41);
            sensitive << a23;
            SC_METHOD(ctos_convert_input_42);
            sensitive << a24;
            SC_METHOD(ctos_convert_input_43);
            sensitive << a25;
            SC_METHOD(ctos_convert_input_44);
            sensitive << a26;
            SC_METHOD(ctos_convert_input_45);
            sensitive << a27;
            SC_METHOD(ctos_convert_input_46);
            sensitive << a28;
            SC_METHOD(ctos_convert_input_47);
            sensitive << a29;
            SC_METHOD(ctos_convert_input_48);
            sensitive << a30;
            SC_METHOD(ctos_convert_input_49);
            sensitive << a31;
            SC_METHOD(ctos_convert_input_50);
            sensitive << b16;
            SC_METHOD(ctos_convert_input_51);
            sensitive << b17;
            SC_METHOD(ctos_convert_input_52);
            sensitive << b18;
            SC_METHOD(ctos_convert_input_53);
            sensitive << b19;
            SC_METHOD(ctos_convert_input_54);
            sensitive << b20;
            SC_METHOD(ctos_convert_input_55);
            sensitive << b21;
            SC_METHOD(ctos_convert_input_56);
            sensitive << b22;
            SC_METHOD(ctos_convert_input_57);
            sensitive << b23;
            SC_METHOD(ctos_convert_input_58);
            sensitive << b24;
            SC_METHOD(ctos_convert_input_59);
            sensitive << b25;
            SC_METHOD(ctos_convert_input_60);
            sensitive << b26;
            SC_METHOD(ctos_convert_input_61);
            sensitive << b27;
            SC_METHOD(ctos_convert_input_62);
            sensitive << b28;
            SC_METHOD(ctos_convert_input_63);
            sensitive << b29;
            SC_METHOD(ctos_convert_input_64);
            sensitive << b30;
            SC_METHOD(ctos_convert_input_65);
            sensitive << b31;
            if (w_flag_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output);
                dont_initialize();
                sensitive << *w_flag_vlog_dut;
            }
            if (s0_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_0);
                dont_initialize();
                sensitive << *s0_vlog_dut;
            }
            if (s1_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_1);
                dont_initialize();
                sensitive << *s1_vlog_dut;
            }
            if (s2_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_2);
                dont_initialize();
                sensitive << *s2_vlog_dut;
            }
            if (s3_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_3);
                dont_initialize();
                sensitive << *s3_vlog_dut;
            }
            if (s4_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_4);
                dont_initialize();
                sensitive << *s4_vlog_dut;
            }
            if (s5_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_5);
                dont_initialize();
                sensitive << *s5_vlog_dut;
            }
            if (s6_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_6);
                dont_initialize();
                sensitive << *s6_vlog_dut;
            }
            if (s7_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_7);
                dont_initialize();
                sensitive << *s7_vlog_dut;
            }
            if (s8_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_8);
                dont_initialize();
                sensitive << *s8_vlog_dut;
            }
            if (s9_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_9);
                dont_initialize();
                sensitive << *s9_vlog_dut;
            }
            if (s10_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_10);
                dont_initialize();
                sensitive << *s10_vlog_dut;
            }
            if (s11_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_11);
                dont_initialize();
                sensitive << *s11_vlog_dut;
            }
            if (s12_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_12);
                dont_initialize();
                sensitive << *s12_vlog_dut;
            }
            if (s13_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_13);
                dont_initialize();
                sensitive << *s13_vlog_dut;
            }
            if (s14_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_14);
                dont_initialize();
                sensitive << *s14_vlog_dut;
            }
            if (s15_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_15);
                dont_initialize();
                sensitive << *s15_vlog_dut;
            }
            if (s16_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_16);
                dont_initialize();
                sensitive << *s16_vlog_dut;
            }
            if (s17_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_17);
                dont_initialize();
                sensitive << *s17_vlog_dut;
            }
            if (s18_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_18);
                dont_initialize();
                sensitive << *s18_vlog_dut;
            }
            if (s19_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_19);
                dont_initialize();
                sensitive << *s19_vlog_dut;
            }
            if (s20_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_20);
                dont_initialize();
                sensitive << *s20_vlog_dut;
            }
            if (s21_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_21);
                dont_initialize();
                sensitive << *s21_vlog_dut;
            }
            if (s22_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_22);
                dont_initialize();
                sensitive << *s22_vlog_dut;
            }
            if (s23_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_23);
                dont_initialize();
                sensitive << *s23_vlog_dut;
            }
            if (s24_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_24);
                dont_initialize();
                sensitive << *s24_vlog_dut;
            }
            if (s25_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_25);
                dont_initialize();
                sensitive << *s25_vlog_dut;
            }
            if (s26_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_26);
                dont_initialize();
                sensitive << *s26_vlog_dut;
            }
            if (s27_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_27);
                dont_initialize();
                sensitive << *s27_vlog_dut;
            }
            if (s28_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_28);
                dont_initialize();
                sensitive << *s28_vlog_dut;
            }
            if (s29_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_29);
                dont_initialize();
                sensitive << *s29_vlog_dut;
            }
            if (s30_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_30);
                dont_initialize();
                sensitive << *s30_vlog_dut;
            }
            if (s31_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_31);
                dont_initialize();
                sensitive << *s31_vlog_dut;
            }
            if (cout_vlog_dut!=NULL) {
                SC_METHOD(ctos_convert_output_32);
                dont_initialize();
                sensitive << *cout_vlog_dut;
            }
        }
        if ((m_ctos_ref_type!=UNKNOWN)&&m_ctos_compare) {
            SC_METHOD(ctos_compare_outputs);
            dont_initialize();
            sensitive << w_flag;
            SC_METHOD(ctos_compare_outputs_0);
            dont_initialize();
            sensitive << s0;
            SC_METHOD(ctos_compare_outputs_1);
            dont_initialize();
            sensitive << s1;
            SC_METHOD(ctos_compare_outputs_2);
            dont_initialize();
            sensitive << s2;
            SC_METHOD(ctos_compare_outputs_3);
            dont_initialize();
            sensitive << s3;
            SC_METHOD(ctos_compare_outputs_4);
            dont_initialize();
            sensitive << s4;
            SC_METHOD(ctos_compare_outputs_5);
            dont_initialize();
            sensitive << s5;
            SC_METHOD(ctos_compare_outputs_6);
            dont_initialize();
            sensitive << s6;
            SC_METHOD(ctos_compare_outputs_7);
            dont_initialize();
            sensitive << s7;
            SC_METHOD(ctos_compare_outputs_8);
            dont_initialize();
            sensitive << s8;
            SC_METHOD(ctos_compare_outputs_9);
            dont_initialize();
            sensitive << s9;
            SC_METHOD(ctos_compare_outputs_10);
            dont_initialize();
            sensitive << s10;
            SC_METHOD(ctos_compare_outputs_11);
            dont_initialize();
            sensitive << s11;
            SC_METHOD(ctos_compare_outputs_12);
            dont_initialize();
            sensitive << s12;
            SC_METHOD(ctos_compare_outputs_13);
            dont_initialize();
            sensitive << s13;
            SC_METHOD(ctos_compare_outputs_14);
            dont_initialize();
            sensitive << s14;
            SC_METHOD(ctos_compare_outputs_15);
            dont_initialize();
            sensitive << s15;
            SC_METHOD(ctos_compare_outputs_16);
            dont_initialize();
            sensitive << s16;
            SC_METHOD(ctos_compare_outputs_17);
            dont_initialize();
            sensitive << s17;
            SC_METHOD(ctos_compare_outputs_18);
            dont_initialize();
            sensitive << s18;
            SC_METHOD(ctos_compare_outputs_19);
            dont_initialize();
            sensitive << s19;
            SC_METHOD(ctos_compare_outputs_20);
            dont_initialize();
            sensitive << s20;
            SC_METHOD(ctos_compare_outputs_21);
            dont_initialize();
            sensitive << s21;
            SC_METHOD(ctos_compare_outputs_22);
            dont_initialize();
            sensitive << s22;
            SC_METHOD(ctos_compare_outputs_23);
            dont_initialize();
            sensitive << s23;
            SC_METHOD(ctos_compare_outputs_24);
            dont_initialize();
            sensitive << s24;
            SC_METHOD(ctos_compare_outputs_25);
            dont_initialize();
            sensitive << s25;
            SC_METHOD(ctos_compare_outputs_26);
            dont_initialize();
            sensitive << s26;
            SC_METHOD(ctos_compare_outputs_27);
            dont_initialize();
            sensitive << s27;
            SC_METHOD(ctos_compare_outputs_28);
            dont_initialize();
            sensitive << s28;
            SC_METHOD(ctos_compare_outputs_29);
            dont_initialize();
            sensitive << s29;
            SC_METHOD(ctos_compare_outputs_30);
            dont_initialize();
            sensitive << s30;
            SC_METHOD(ctos_compare_outputs_31);
            dont_initialize();
            sensitive << s31;
            SC_METHOD(ctos_compare_outputs_32);
            dont_initialize();
            sensitive << cout;
        }
    }
    // clock clk period 1000 rise 0 fall 500
    sc_in<bool>  clk;
    // reset reset false
    sc_in<bool>  reset;
    sc_in<bool>  cin;
    sc_in<bool>  pwr_sig;
    sc_in<bool>  clk_gate;
    sc_in<bool>  a0;
    sc_in<bool>  a1;
    sc_in<bool>  a2;
    sc_in<bool>  a3;
    sc_in<bool>  a4;
    sc_in<bool>  a5;
    sc_in<bool>  a6;
    sc_in<bool>  a7;
    sc_in<bool>  a8;
    sc_in<bool>  a9;
    sc_in<bool>  a10;
    sc_in<bool>  a11;
    sc_in<bool>  a12;
    sc_in<bool>  a13;
    sc_in<bool>  a14;
    sc_in<bool>  a15;
    sc_in<bool>  b0;
    sc_in<bool>  b1;
    sc_in<bool>  b2;
    sc_in<bool>  b3;
    sc_in<bool>  b4;
    sc_in<bool>  b5;
    sc_in<bool>  b6;
    sc_in<bool>  b7;
    sc_in<bool>  b8;
    sc_in<bool>  b9;
    sc_in<bool>  b10;
    sc_in<bool>  b11;
    sc_in<bool>  b12;
    sc_in<bool>  b13;
    sc_in<bool>  b14;
    sc_in<bool>  b15;
    sc_in<bool>  a16;
    sc_in<bool>  a17;
    sc_in<bool>  a18;
    sc_in<bool>  a19;
    sc_in<bool>  a20;
    sc_in<bool>  a21;
    sc_in<bool>  a22;
    sc_in<bool>  a23;
    sc_in<bool>  a24;
    sc_in<bool>  a25;
    sc_in<bool>  a26;
    sc_in<bool>  a27;
    sc_in<bool>  a28;
    sc_in<bool>  a29;
    sc_in<bool>  a30;
    sc_in<bool>  a31;
    sc_in<bool>  b16;
    sc_in<bool>  b17;
    sc_in<bool>  b18;
    sc_in<bool>  b19;
    sc_in<bool>  b20;
    sc_in<bool>  b21;
    sc_in<bool>  b22;
    sc_in<bool>  b23;
    sc_in<bool>  b24;
    sc_in<bool>  b25;
    sc_in<bool>  b26;
    sc_in<bool>  b27;
    sc_in<bool>  b28;
    sc_in<bool>  b29;
    sc_in<bool>  b30;
    sc_in<bool>  b31;
    sc_out<bool>  w_flag;
    sc_out<bool>  s0;
    sc_out<bool>  s1;
    sc_out<bool>  s2;
    sc_out<bool>  s3;
    sc_out<bool>  s4;
    sc_out<bool>  s5;
    sc_out<bool>  s6;
    sc_out<bool>  s7;
    sc_out<bool>  s8;
    sc_out<bool>  s9;
    sc_out<bool>  s10;
    sc_out<bool>  s11;
    sc_out<bool>  s12;
    sc_out<bool>  s13;
    sc_out<bool>  s14;
    sc_out<bool>  s15;
    sc_out<bool>  s16;
    sc_out<bool>  s17;
    sc_out<bool>  s18;
    sc_out<bool>  s19;
    sc_out<bool>  s20;
    sc_out<bool>  s21;
    sc_out<bool>  s22;
    sc_out<bool>  s23;
    sc_out<bool>  s24;
    sc_out<bool>  s25;
    sc_out<bool>  s26;
    sc_out<bool>  s27;
    sc_out<bool>  s28;
    sc_out<bool>  s29;
    sc_out<bool>  s30;
    sc_out<bool>  s31;
    sc_out<bool>  cout;
    sc_event m_ctosWrapperError;
    bool m_enableCompare;
    
    enum SimulateRTLOnlyEnum {
        Unsupported = 0,
        SimulateRTLOnly = 1
    };

  private:
    
    enum ModelTypeEnum {
        ORIG = 0,
        VLOG = 2,
        UNKNOWN = 3
    };

    sc_signal<sc_lv<1> >  *cin_vlog;
    sc_signal<sc_lv<1> >  *pwr_sig_vlog;
    sc_signal<sc_lv<1> >  *clk_gate_vlog;
    sc_signal<sc_lv<1> >  *a0_vlog;
    sc_signal<sc_lv<1> >  *a1_vlog;
    sc_signal<sc_lv<1> >  *a2_vlog;
    sc_signal<sc_lv<1> >  *a3_vlog;
    sc_signal<sc_lv<1> >  *a4_vlog;
    sc_signal<sc_lv<1> >  *a5_vlog;
    sc_signal<sc_lv<1> >  *a6_vlog;
    sc_signal<sc_lv<1> >  *a7_vlog;
    sc_signal<sc_lv<1> >  *a8_vlog;
    sc_signal<sc_lv<1> >  *a9_vlog;
    sc_signal<sc_lv<1> >  *a10_vlog;
    sc_signal<sc_lv<1> >  *a11_vlog;
    sc_signal<sc_lv<1> >  *a12_vlog;
    sc_signal<sc_lv<1> >  *a13_vlog;
    sc_signal<sc_lv<1> >  *a14_vlog;
    sc_signal<sc_lv<1> >  *a15_vlog;
    sc_signal<sc_lv<1> >  *b0_vlog;
    sc_signal<sc_lv<1> >  *b1_vlog;
    sc_signal<sc_lv<1> >  *b2_vlog;
    sc_signal<sc_lv<1> >  *b3_vlog;
    sc_signal<sc_lv<1> >  *b4_vlog;
    sc_signal<sc_lv<1> >  *b5_vlog;
    sc_signal<sc_lv<1> >  *b6_vlog;
    sc_signal<sc_lv<1> >  *b7_vlog;
    sc_signal<sc_lv<1> >  *b8_vlog;
    sc_signal<sc_lv<1> >  *b9_vlog;
    sc_signal<sc_lv<1> >  *b10_vlog;
    sc_signal<sc_lv<1> >  *b11_vlog;
    sc_signal<sc_lv<1> >  *b12_vlog;
    sc_signal<sc_lv<1> >  *b13_vlog;
    sc_signal<sc_lv<1> >  *b14_vlog;
    sc_signal<sc_lv<1> >  *b15_vlog;
    sc_signal<sc_lv<1> >  *a16_vlog;
    sc_signal<sc_lv<1> >  *a17_vlog;
    sc_signal<sc_lv<1> >  *a18_vlog;
    sc_signal<sc_lv<1> >  *a19_vlog;
    sc_signal<sc_lv<1> >  *a20_vlog;
    sc_signal<sc_lv<1> >  *a21_vlog;
    sc_signal<sc_lv<1> >  *a22_vlog;
    sc_signal<sc_lv<1> >  *a23_vlog;
    sc_signal<sc_lv<1> >  *a24_vlog;
    sc_signal<sc_lv<1> >  *a25_vlog;
    sc_signal<sc_lv<1> >  *a26_vlog;
    sc_signal<sc_lv<1> >  *a27_vlog;
    sc_signal<sc_lv<1> >  *a28_vlog;
    sc_signal<sc_lv<1> >  *a29_vlog;
    sc_signal<sc_lv<1> >  *a30_vlog;
    sc_signal<sc_lv<1> >  *a31_vlog;
    sc_signal<sc_lv<1> >  *b16_vlog;
    sc_signal<sc_lv<1> >  *b17_vlog;
    sc_signal<sc_lv<1> >  *b18_vlog;
    sc_signal<sc_lv<1> >  *b19_vlog;
    sc_signal<sc_lv<1> >  *b20_vlog;
    sc_signal<sc_lv<1> >  *b21_vlog;
    sc_signal<sc_lv<1> >  *b22_vlog;
    sc_signal<sc_lv<1> >  *b23_vlog;
    sc_signal<sc_lv<1> >  *b24_vlog;
    sc_signal<sc_lv<1> >  *b25_vlog;
    sc_signal<sc_lv<1> >  *b26_vlog;
    sc_signal<sc_lv<1> >  *b27_vlog;
    sc_signal<sc_lv<1> >  *b28_vlog;
    sc_signal<sc_lv<1> >  *b29_vlog;
    sc_signal<sc_lv<1> >  *b30_vlog;
    sc_signal<sc_lv<1> >  *b31_vlog;
    sc_signal<sc_lv<1> >  *w_flag_vlog_dut;
    sc_signal<sc_lv<1> >  *w_flag_vlog_ref;
    sc_signal<bool>  w_flag_cpp;
    sc_signal<sc_lv<1> >  *s0_vlog_dut;
    sc_signal<sc_lv<1> >  *s0_vlog_ref;
    sc_signal<bool>  s0_cpp;
    sc_signal<sc_lv<1> >  *s1_vlog_dut;
    sc_signal<sc_lv<1> >  *s1_vlog_ref;
    sc_signal<bool>  s1_cpp;
    sc_signal<sc_lv<1> >  *s2_vlog_dut;
    sc_signal<sc_lv<1> >  *s2_vlog_ref;
    sc_signal<bool>  s2_cpp;
    sc_signal<sc_lv<1> >  *s3_vlog_dut;
    sc_signal<sc_lv<1> >  *s3_vlog_ref;
    sc_signal<bool>  s3_cpp;
    sc_signal<sc_lv<1> >  *s4_vlog_dut;
    sc_signal<sc_lv<1> >  *s4_vlog_ref;
    sc_signal<bool>  s4_cpp;
    sc_signal<sc_lv<1> >  *s5_vlog_dut;
    sc_signal<sc_lv<1> >  *s5_vlog_ref;
    sc_signal<bool>  s5_cpp;
    sc_signal<sc_lv<1> >  *s6_vlog_dut;
    sc_signal<sc_lv<1> >  *s6_vlog_ref;
    sc_signal<bool>  s6_cpp;
    sc_signal<sc_lv<1> >  *s7_vlog_dut;
    sc_signal<sc_lv<1> >  *s7_vlog_ref;
    sc_signal<bool>  s7_cpp;
    sc_signal<sc_lv<1> >  *s8_vlog_dut;
    sc_signal<sc_lv<1> >  *s8_vlog_ref;
    sc_signal<bool>  s8_cpp;
    sc_signal<sc_lv<1> >  *s9_vlog_dut;
    sc_signal<sc_lv<1> >  *s9_vlog_ref;
    sc_signal<bool>  s9_cpp;
    sc_signal<sc_lv<1> >  *s10_vlog_dut;
    sc_signal<sc_lv<1> >  *s10_vlog_ref;
    sc_signal<bool>  s10_cpp;
    sc_signal<sc_lv<1> >  *s11_vlog_dut;
    sc_signal<sc_lv<1> >  *s11_vlog_ref;
    sc_signal<bool>  s11_cpp;
    sc_signal<sc_lv<1> >  *s12_vlog_dut;
    sc_signal<sc_lv<1> >  *s12_vlog_ref;
    sc_signal<bool>  s12_cpp;
    sc_signal<sc_lv<1> >  *s13_vlog_dut;
    sc_signal<sc_lv<1> >  *s13_vlog_ref;
    sc_signal<bool>  s13_cpp;
    sc_signal<sc_lv<1> >  *s14_vlog_dut;
    sc_signal<sc_lv<1> >  *s14_vlog_ref;
    sc_signal<bool>  s14_cpp;
    sc_signal<sc_lv<1> >  *s15_vlog_dut;
    sc_signal<sc_lv<1> >  *s15_vlog_ref;
    sc_signal<bool>  s15_cpp;
    sc_signal<sc_lv<1> >  *s16_vlog_dut;
    sc_signal<sc_lv<1> >  *s16_vlog_ref;
    sc_signal<bool>  s16_cpp;
    sc_signal<sc_lv<1> >  *s17_vlog_dut;
    sc_signal<sc_lv<1> >  *s17_vlog_ref;
    sc_signal<bool>  s17_cpp;
    sc_signal<sc_lv<1> >  *s18_vlog_dut;
    sc_signal<sc_lv<1> >  *s18_vlog_ref;
    sc_signal<bool>  s18_cpp;
    sc_signal<sc_lv<1> >  *s19_vlog_dut;
    sc_signal<sc_lv<1> >  *s19_vlog_ref;
    sc_signal<bool>  s19_cpp;
    sc_signal<sc_lv<1> >  *s20_vlog_dut;
    sc_signal<sc_lv<1> >  *s20_vlog_ref;
    sc_signal<bool>  s20_cpp;
    sc_signal<sc_lv<1> >  *s21_vlog_dut;
    sc_signal<sc_lv<1> >  *s21_vlog_ref;
    sc_signal<bool>  s21_cpp;
    sc_signal<sc_lv<1> >  *s22_vlog_dut;
    sc_signal<sc_lv<1> >  *s22_vlog_ref;
    sc_signal<bool>  s22_cpp;
    sc_signal<sc_lv<1> >  *s23_vlog_dut;
    sc_signal<sc_lv<1> >  *s23_vlog_ref;
    sc_signal<bool>  s23_cpp;
    sc_signal<sc_lv<1> >  *s24_vlog_dut;
    sc_signal<sc_lv<1> >  *s24_vlog_ref;
    sc_signal<bool>  s24_cpp;
    sc_signal<sc_lv<1> >  *s25_vlog_dut;
    sc_signal<sc_lv<1> >  *s25_vlog_ref;
    sc_signal<bool>  s25_cpp;
    sc_signal<sc_lv<1> >  *s26_vlog_dut;
    sc_signal<sc_lv<1> >  *s26_vlog_ref;
    sc_signal<bool>  s26_cpp;
    sc_signal<sc_lv<1> >  *s27_vlog_dut;
    sc_signal<sc_lv<1> >  *s27_vlog_ref;
    sc_signal<bool>  s27_cpp;
    sc_signal<sc_lv<1> >  *s28_vlog_dut;
    sc_signal<sc_lv<1> >  *s28_vlog_ref;
    sc_signal<bool>  s28_cpp;
    sc_signal<sc_lv<1> >  *s29_vlog_dut;
    sc_signal<sc_lv<1> >  *s29_vlog_ref;
    sc_signal<bool>  s29_cpp;
    sc_signal<sc_lv<1> >  *s30_vlog_dut;
    sc_signal<sc_lv<1> >  *s30_vlog_ref;
    sc_signal<bool>  s30_cpp;
    sc_signal<sc_lv<1> >  *s31_vlog_dut;
    sc_signal<sc_lv<1> >  *s31_vlog_ref;
    sc_signal<bool>  s31_cpp;
    sc_signal<sc_lv<1> >  *cout_vlog_dut;
    sc_signal<sc_lv<1> >  *cout_vlog_ref;
    sc_signal<bool>  cout_cpp;
    ModelTypeEnum m_ctos_dut_type;
    ModelTypeEnum m_ctos_ref_type;
    bool m_ctos_compare;
    
    union {
      public:
        RCA_32b *m_ref_cpp;
        RCA_32b_ctos_wrapper_vlog *m_ref_vlog;
    };

    
    union {
      public:
        RCA_32b *m_dut_cpp;
        RCA_32b_ctos_wrapper_vlog *m_dut_vlog;
    };

    // Converts input string to enumeration
    ModelTypeEnum modelTypeLookUp(char  const *str)
    {
        if (!str) {
            return UNKNOWN;
        }
        std::string inputString = str;
        if (inputString.empty()) {
            return ORIG;
        } else {
            return VLOG;
        }
    }
    
    template <class T, class U> 
    bool ctos_check_unknown_values(T  const *dutSig, U  const &refSig, std::string  const &dutName, std::string  const &refName)
    {
        if (!(dutSig->read().is_01())) {
            std::cout << sc_time_stamp()
            	      << ": ctos_check_unknown_values encountered unknown values!"
            	      << std::endl << dutName << ": " << (dutSig->read().to_string())
            	      << std::endl << refName << ": " << refSig << std::endl;
        }
        return true;
    }
    
    template <class T> 
    void ctos_compare_output_values(T  const &dutSig, T  const &refSig, std::string  const &dutName, std::string  const &refName)
    {
        if (!(dutSig==refSig)) {
            std::cout << sc_time_stamp()
            	      << ": ctos_compare_output_values mismatch!"
            	      << std::endl << dutName << ": " << dutSig
            	      << std::endl << refName << ": " << refSig << std::endl;
            m_ctosWrapperError.notify();
        }
    }
    void ctos_convert_input()
    {
        *cin_vlog=sc_lv<1> ((cin.read()));
    }
    void ctos_convert_input_0()
    {
        *pwr_sig_vlog=sc_lv<1> ((pwr_sig.read()));
    }
    void ctos_convert_input_1()
    {
        *clk_gate_vlog=sc_lv<1> ((clk_gate.read()));
    }
    void ctos_convert_input_2()
    {
        *a0_vlog=sc_lv<1> ((a0.read()));
    }
    void ctos_convert_input_3()
    {
        *a1_vlog=sc_lv<1> ((a1.read()));
    }
    void ctos_convert_input_4()
    {
        *a2_vlog=sc_lv<1> ((a2.read()));
    }
    void ctos_convert_input_5()
    {
        *a3_vlog=sc_lv<1> ((a3.read()));
    }
    void ctos_convert_input_6()
    {
        *a4_vlog=sc_lv<1> ((a4.read()));
    }
    void ctos_convert_input_7()
    {
        *a5_vlog=sc_lv<1> ((a5.read()));
    }
    void ctos_convert_input_8()
    {
        *a6_vlog=sc_lv<1> ((a6.read()));
    }
    void ctos_convert_input_9()
    {
        *a7_vlog=sc_lv<1> ((a7.read()));
    }
    void ctos_convert_input_10()
    {
        *a8_vlog=sc_lv<1> ((a8.read()));
    }
    void ctos_convert_input_11()
    {
        *a9_vlog=sc_lv<1> ((a9.read()));
    }
    void ctos_convert_input_12()
    {
        *a10_vlog=sc_lv<1> ((a10.read()));
    }
    void ctos_convert_input_13()
    {
        *a11_vlog=sc_lv<1> ((a11.read()));
    }
    void ctos_convert_input_14()
    {
        *a12_vlog=sc_lv<1> ((a12.read()));
    }
    void ctos_convert_input_15()
    {
        *a13_vlog=sc_lv<1> ((a13.read()));
    }
    void ctos_convert_input_16()
    {
        *a14_vlog=sc_lv<1> ((a14.read()));
    }
    void ctos_convert_input_17()
    {
        *a15_vlog=sc_lv<1> ((a15.read()));
    }
    void ctos_convert_input_18()
    {
        *b0_vlog=sc_lv<1> ((b0.read()));
    }
    void ctos_convert_input_19()
    {
        *b1_vlog=sc_lv<1> ((b1.read()));
    }
    void ctos_convert_input_20()
    {
        *b2_vlog=sc_lv<1> ((b2.read()));
    }
    void ctos_convert_input_21()
    {
        *b3_vlog=sc_lv<1> ((b3.read()));
    }
    void ctos_convert_input_22()
    {
        *b4_vlog=sc_lv<1> ((b4.read()));
    }
    void ctos_convert_input_23()
    {
        *b5_vlog=sc_lv<1> ((b5.read()));
    }
    void ctos_convert_input_24()
    {
        *b6_vlog=sc_lv<1> ((b6.read()));
    }
    void ctos_convert_input_25()
    {
        *b7_vlog=sc_lv<1> ((b7.read()));
    }
    void ctos_convert_input_26()
    {
        *b8_vlog=sc_lv<1> ((b8.read()));
    }
    void ctos_convert_input_27()
    {
        *b9_vlog=sc_lv<1> ((b9.read()));
    }
    void ctos_convert_input_28()
    {
        *b10_vlog=sc_lv<1> ((b10.read()));
    }
    void ctos_convert_input_29()
    {
        *b11_vlog=sc_lv<1> ((b11.read()));
    }
    void ctos_convert_input_30()
    {
        *b12_vlog=sc_lv<1> ((b12.read()));
    }
    void ctos_convert_input_31()
    {
        *b13_vlog=sc_lv<1> ((b13.read()));
    }
    void ctos_convert_input_32()
    {
        *b14_vlog=sc_lv<1> ((b14.read()));
    }
    void ctos_convert_input_33()
    {
        *b15_vlog=sc_lv<1> ((b15.read()));
    }
    void ctos_convert_input_34()
    {
        *a16_vlog=sc_lv<1> ((a16.read()));
    }
    void ctos_convert_input_35()
    {
        *a17_vlog=sc_lv<1> ((a17.read()));
    }
    void ctos_convert_input_36()
    {
        *a18_vlog=sc_lv<1> ((a18.read()));
    }
    void ctos_convert_input_37()
    {
        *a19_vlog=sc_lv<1> ((a19.read()));
    }
    void ctos_convert_input_38()
    {
        *a20_vlog=sc_lv<1> ((a20.read()));
    }
    void ctos_convert_input_39()
    {
        *a21_vlog=sc_lv<1> ((a21.read()));
    }
    void ctos_convert_input_40()
    {
        *a22_vlog=sc_lv<1> ((a22.read()));
    }
    void ctos_convert_input_41()
    {
        *a23_vlog=sc_lv<1> ((a23.read()));
    }
    void ctos_convert_input_42()
    {
        *a24_vlog=sc_lv<1> ((a24.read()));
    }
    void ctos_convert_input_43()
    {
        *a25_vlog=sc_lv<1> ((a25.read()));
    }
    void ctos_convert_input_44()
    {
        *a26_vlog=sc_lv<1> ((a26.read()));
    }
    void ctos_convert_input_45()
    {
        *a27_vlog=sc_lv<1> ((a27.read()));
    }
    void ctos_convert_input_46()
    {
        *a28_vlog=sc_lv<1> ((a28.read()));
    }
    void ctos_convert_input_47()
    {
        *a29_vlog=sc_lv<1> ((a29.read()));
    }
    void ctos_convert_input_48()
    {
        *a30_vlog=sc_lv<1> ((a30.read()));
    }
    void ctos_convert_input_49()
    {
        *a31_vlog=sc_lv<1> ((a31.read()));
    }
    void ctos_convert_input_50()
    {
        *b16_vlog=sc_lv<1> ((b16.read()));
    }
    void ctos_convert_input_51()
    {
        *b17_vlog=sc_lv<1> ((b17.read()));
    }
    void ctos_convert_input_52()
    {
        *b18_vlog=sc_lv<1> ((b18.read()));
    }
    void ctos_convert_input_53()
    {
        *b19_vlog=sc_lv<1> ((b19.read()));
    }
    void ctos_convert_input_54()
    {
        *b20_vlog=sc_lv<1> ((b20.read()));
    }
    void ctos_convert_input_55()
    {
        *b21_vlog=sc_lv<1> ((b21.read()));
    }
    void ctos_convert_input_56()
    {
        *b22_vlog=sc_lv<1> ((b22.read()));
    }
    void ctos_convert_input_57()
    {
        *b23_vlog=sc_lv<1> ((b23.read()));
    }
    void ctos_convert_input_58()
    {
        *b24_vlog=sc_lv<1> ((b24.read()));
    }
    void ctos_convert_input_59()
    {
        *b25_vlog=sc_lv<1> ((b25.read()));
    }
    void ctos_convert_input_60()
    {
        *b26_vlog=sc_lv<1> ((b26.read()));
    }
    void ctos_convert_input_61()
    {
        *b27_vlog=sc_lv<1> ((b27.read()));
    }
    void ctos_convert_input_62()
    {
        *b28_vlog=sc_lv<1> ((b28.read()));
    }
    void ctos_convert_input_63()
    {
        *b29_vlog=sc_lv<1> ((b29.read()));
    }
    void ctos_convert_input_64()
    {
        *b30_vlog=sc_lv<1> ((b30.read()));
    }
    void ctos_convert_input_65()
    {
        *b31_vlog=sc_lv<1> ((b31.read()));
    }
    void ctos_convert_output()
    {
        w_flag=w_flag_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_0()
    {
        s0=s0_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_1()
    {
        s1=s1_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_2()
    {
        s2=s2_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_3()
    {
        s3=s3_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_4()
    {
        s4=s4_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_5()
    {
        s5=s5_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_6()
    {
        s6=s6_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_7()
    {
        s7=s7_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_8()
    {
        s8=s8_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_9()
    {
        s9=s9_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_10()
    {
        s10=s10_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_11()
    {
        s11=s11_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_12()
    {
        s12=s12_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_13()
    {
        s13=s13_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_14()
    {
        s14=s14_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_15()
    {
        s15=s15_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_16()
    {
        s16=s16_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_17()
    {
        s17=s17_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_18()
    {
        s18=s18_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_19()
    {
        s19=s19_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_20()
    {
        s20=s20_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_21()
    {
        s21=s21_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_22()
    {
        s22=s22_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_23()
    {
        s23=s23_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_24()
    {
        s24=s24_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_25()
    {
        s25=s25_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_26()
    {
        s26=s26_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_27()
    {
        s27=s27_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_28()
    {
        s28=s28_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_29()
    {
        s29=s29_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_30()
    {
        s30=s30_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_31()
    {
        s31=s31_vlog_dut->read().to_uint();
    }
    void ctos_convert_output_32()
    {
        cout=cout_vlog_dut->read().to_uint();
    }
    void ctos_compare_outputs()
    {}
    void ctos_compare_outputs_0()
    {}
    void ctos_compare_outputs_1()
    {}
    void ctos_compare_outputs_2()
    {}
    void ctos_compare_outputs_3()
    {}
    void ctos_compare_outputs_4()
    {}
    void ctos_compare_outputs_5()
    {}
    void ctos_compare_outputs_6()
    {}
    void ctos_compare_outputs_7()
    {}
    void ctos_compare_outputs_8()
    {}
    void ctos_compare_outputs_9()
    {}
    void ctos_compare_outputs_10()
    {}
    void ctos_compare_outputs_11()
    {}
    void ctos_compare_outputs_12()
    {}
    void ctos_compare_outputs_13()
    {}
    void ctos_compare_outputs_14()
    {}
    void ctos_compare_outputs_15()
    {}
    void ctos_compare_outputs_16()
    {}
    void ctos_compare_outputs_17()
    {}
    void ctos_compare_outputs_18()
    {}
    void ctos_compare_outputs_19()
    {}
    void ctos_compare_outputs_20()
    {}
    void ctos_compare_outputs_21()
    {}
    void ctos_compare_outputs_22()
    {}
    void ctos_compare_outputs_23()
    {}
    void ctos_compare_outputs_24()
    {}
    void ctos_compare_outputs_25()
    {}
    void ctos_compare_outputs_26()
    {}
    void ctos_compare_outputs_27()
    {}
    void ctos_compare_outputs_28()
    {}
    void ctos_compare_outputs_29()
    {}
    void ctos_compare_outputs_30()
    {}
    void ctos_compare_outputs_31()
    {}
    void ctos_compare_outputs_32()
    {}
  public:
    // Use this constructor only if your CtoS verilog model has no suffix
    RCA_32b_ctos_wrapper(sc_module_name name, SimulateRTLOnlyEnum simulateRTLOnly)
    :   sc_module(name),
        clk("clk"),
        reset("reset"),
        cin("cin"),
        pwr_sig("pwr_sig"),
        clk_gate("clk_gate"),
        a0("a0"),
        a1("a1"),
        a2("a2"),
        a3("a3"),
        a4("a4"),
        a5("a5"),
        a6("a6"),
        a7("a7"),
        a8("a8"),
        a9("a9"),
        a10("a10"),
        a11("a11"),
        a12("a12"),
        a13("a13"),
        a14("a14"),
        a15("a15"),
        b0("b0"),
        b1("b1"),
        b2("b2"),
        b3("b3"),
        b4("b4"),
        b5("b5"),
        b6("b6"),
        b7("b7"),
        b8("b8"),
        b9("b9"),
        b10("b10"),
        b11("b11"),
        b12("b12"),
        b13("b13"),
        b14("b14"),
        b15("b15"),
        a16("a16"),
        a17("a17"),
        a18("a18"),
        a19("a19"),
        a20("a20"),
        a21("a21"),
        a22("a22"),
        a23("a23"),
        a24("a24"),
        a25("a25"),
        a26("a26"),
        a27("a27"),
        a28("a28"),
        a29("a29"),
        a30("a30"),
        a31("a31"),
        b16("b16"),
        b17("b17"),
        b18("b18"),
        b19("b19"),
        b20("b20"),
        b21("b21"),
        b22("b22"),
        b23("b23"),
        b24("b24"),
        b25("b25"),
        b26("b26"),
        b27("b27"),
        b28("b28"),
        b29("b29"),
        b30("b30"),
        b31("b31"),
        w_flag("w_flag"),
        s0("s0"),
        s1("s1"),
        s2("s2"),
        s3("s3"),
        s4("s4"),
        s5("s5"),
        s6("s6"),
        s7("s7"),
        s8("s8"),
        s9("s9"),
        s10("s10"),
        s11("s11"),
        s12("s12"),
        s13("s13"),
        s14("s14"),
        s15("s15"),
        s16("s16"),
        s17("s17"),
        s18("s18"),
        s19("s19"),
        s20("s20"),
        s21("s21"),
        s22("s22"),
        s23("s23"),
        s24("s24"),
        s25("s25"),
        s26("s26"),
        s27("s27"),
        s28("s28"),
        s29("s29"),
        s30("s30"),
        s31("s31"),
        cout("cout"),
        m_enableCompare(false),
        m_ctos_compare(false)
    {
        m_ctos_dut_type=VLOG;
        m_ctos_ref_type=UNKNOWN;
        m_dut_vlog=new RCA_32b_ctos_wrapper_vlog("m_dut_vlog", "");
        m_dut_vlog->clk(clk);
        m_dut_vlog->reset(reset);
        cin_vlog=new sc_signal<sc_lv<1> > ("cin_vlog");
        m_dut_vlog->cin(*cin_vlog);
        pwr_sig_vlog=new sc_signal<sc_lv<1> > ("pwr_sig_vlog");
        m_dut_vlog->pwr_sig(*pwr_sig_vlog);
        clk_gate_vlog=new sc_signal<sc_lv<1> > ("clk_gate_vlog");
        m_dut_vlog->clk_gate(*clk_gate_vlog);
        a0_vlog=new sc_signal<sc_lv<1> > ("a0_vlog");
        m_dut_vlog->a0(*a0_vlog);
        a1_vlog=new sc_signal<sc_lv<1> > ("a1_vlog");
        m_dut_vlog->a1(*a1_vlog);
        a2_vlog=new sc_signal<sc_lv<1> > ("a2_vlog");
        m_dut_vlog->a2(*a2_vlog);
        a3_vlog=new sc_signal<sc_lv<1> > ("a3_vlog");
        m_dut_vlog->a3(*a3_vlog);
        a4_vlog=new sc_signal<sc_lv<1> > ("a4_vlog");
        m_dut_vlog->a4(*a4_vlog);
        a5_vlog=new sc_signal<sc_lv<1> > ("a5_vlog");
        m_dut_vlog->a5(*a5_vlog);
        a6_vlog=new sc_signal<sc_lv<1> > ("a6_vlog");
        m_dut_vlog->a6(*a6_vlog);
        a7_vlog=new sc_signal<sc_lv<1> > ("a7_vlog");
        m_dut_vlog->a7(*a7_vlog);
        a8_vlog=new sc_signal<sc_lv<1> > ("a8_vlog");
        m_dut_vlog->a8(*a8_vlog);
        a9_vlog=new sc_signal<sc_lv<1> > ("a9_vlog");
        m_dut_vlog->a9(*a9_vlog);
        a10_vlog=new sc_signal<sc_lv<1> > ("a10_vlog");
        m_dut_vlog->a10(*a10_vlog);
        a11_vlog=new sc_signal<sc_lv<1> > ("a11_vlog");
        m_dut_vlog->a11(*a11_vlog);
        a12_vlog=new sc_signal<sc_lv<1> > ("a12_vlog");
        m_dut_vlog->a12(*a12_vlog);
        a13_vlog=new sc_signal<sc_lv<1> > ("a13_vlog");
        m_dut_vlog->a13(*a13_vlog);
        a14_vlog=new sc_signal<sc_lv<1> > ("a14_vlog");
        m_dut_vlog->a14(*a14_vlog);
        a15_vlog=new sc_signal<sc_lv<1> > ("a15_vlog");
        m_dut_vlog->a15(*a15_vlog);
        b0_vlog=new sc_signal<sc_lv<1> > ("b0_vlog");
        m_dut_vlog->b0(*b0_vlog);
        b1_vlog=new sc_signal<sc_lv<1> > ("b1_vlog");
        m_dut_vlog->b1(*b1_vlog);
        b2_vlog=new sc_signal<sc_lv<1> > ("b2_vlog");
        m_dut_vlog->b2(*b2_vlog);
        b3_vlog=new sc_signal<sc_lv<1> > ("b3_vlog");
        m_dut_vlog->b3(*b3_vlog);
        b4_vlog=new sc_signal<sc_lv<1> > ("b4_vlog");
        m_dut_vlog->b4(*b4_vlog);
        b5_vlog=new sc_signal<sc_lv<1> > ("b5_vlog");
        m_dut_vlog->b5(*b5_vlog);
        b6_vlog=new sc_signal<sc_lv<1> > ("b6_vlog");
        m_dut_vlog->b6(*b6_vlog);
        b7_vlog=new sc_signal<sc_lv<1> > ("b7_vlog");
        m_dut_vlog->b7(*b7_vlog);
        b8_vlog=new sc_signal<sc_lv<1> > ("b8_vlog");
        m_dut_vlog->b8(*b8_vlog);
        b9_vlog=new sc_signal<sc_lv<1> > ("b9_vlog");
        m_dut_vlog->b9(*b9_vlog);
        b10_vlog=new sc_signal<sc_lv<1> > ("b10_vlog");
        m_dut_vlog->b10(*b10_vlog);
        b11_vlog=new sc_signal<sc_lv<1> > ("b11_vlog");
        m_dut_vlog->b11(*b11_vlog);
        b12_vlog=new sc_signal<sc_lv<1> > ("b12_vlog");
        m_dut_vlog->b12(*b12_vlog);
        b13_vlog=new sc_signal<sc_lv<1> > ("b13_vlog");
        m_dut_vlog->b13(*b13_vlog);
        b14_vlog=new sc_signal<sc_lv<1> > ("b14_vlog");
        m_dut_vlog->b14(*b14_vlog);
        b15_vlog=new sc_signal<sc_lv<1> > ("b15_vlog");
        m_dut_vlog->b15(*b15_vlog);
        a16_vlog=new sc_signal<sc_lv<1> > ("a16_vlog");
        m_dut_vlog->a16(*a16_vlog);
        a17_vlog=new sc_signal<sc_lv<1> > ("a17_vlog");
        m_dut_vlog->a17(*a17_vlog);
        a18_vlog=new sc_signal<sc_lv<1> > ("a18_vlog");
        m_dut_vlog->a18(*a18_vlog);
        a19_vlog=new sc_signal<sc_lv<1> > ("a19_vlog");
        m_dut_vlog->a19(*a19_vlog);
        a20_vlog=new sc_signal<sc_lv<1> > ("a20_vlog");
        m_dut_vlog->a20(*a20_vlog);
        a21_vlog=new sc_signal<sc_lv<1> > ("a21_vlog");
        m_dut_vlog->a21(*a21_vlog);
        a22_vlog=new sc_signal<sc_lv<1> > ("a22_vlog");
        m_dut_vlog->a22(*a22_vlog);
        a23_vlog=new sc_signal<sc_lv<1> > ("a23_vlog");
        m_dut_vlog->a23(*a23_vlog);
        a24_vlog=new sc_signal<sc_lv<1> > ("a24_vlog");
        m_dut_vlog->a24(*a24_vlog);
        a25_vlog=new sc_signal<sc_lv<1> > ("a25_vlog");
        m_dut_vlog->a25(*a25_vlog);
        a26_vlog=new sc_signal<sc_lv<1> > ("a26_vlog");
        m_dut_vlog->a26(*a26_vlog);
        a27_vlog=new sc_signal<sc_lv<1> > ("a27_vlog");
        m_dut_vlog->a27(*a27_vlog);
        a28_vlog=new sc_signal<sc_lv<1> > ("a28_vlog");
        m_dut_vlog->a28(*a28_vlog);
        a29_vlog=new sc_signal<sc_lv<1> > ("a29_vlog");
        m_dut_vlog->a29(*a29_vlog);
        a30_vlog=new sc_signal<sc_lv<1> > ("a30_vlog");
        m_dut_vlog->a30(*a30_vlog);
        a31_vlog=new sc_signal<sc_lv<1> > ("a31_vlog");
        m_dut_vlog->a31(*a31_vlog);
        b16_vlog=new sc_signal<sc_lv<1> > ("b16_vlog");
        m_dut_vlog->b16(*b16_vlog);
        b17_vlog=new sc_signal<sc_lv<1> > ("b17_vlog");
        m_dut_vlog->b17(*b17_vlog);
        b18_vlog=new sc_signal<sc_lv<1> > ("b18_vlog");
        m_dut_vlog->b18(*b18_vlog);
        b19_vlog=new sc_signal<sc_lv<1> > ("b19_vlog");
        m_dut_vlog->b19(*b19_vlog);
        b20_vlog=new sc_signal<sc_lv<1> > ("b20_vlog");
        m_dut_vlog->b20(*b20_vlog);
        b21_vlog=new sc_signal<sc_lv<1> > ("b21_vlog");
        m_dut_vlog->b21(*b21_vlog);
        b22_vlog=new sc_signal<sc_lv<1> > ("b22_vlog");
        m_dut_vlog->b22(*b22_vlog);
        b23_vlog=new sc_signal<sc_lv<1> > ("b23_vlog");
        m_dut_vlog->b23(*b23_vlog);
        b24_vlog=new sc_signal<sc_lv<1> > ("b24_vlog");
        m_dut_vlog->b24(*b24_vlog);
        b25_vlog=new sc_signal<sc_lv<1> > ("b25_vlog");
        m_dut_vlog->b25(*b25_vlog);
        b26_vlog=new sc_signal<sc_lv<1> > ("b26_vlog");
        m_dut_vlog->b26(*b26_vlog);
        b27_vlog=new sc_signal<sc_lv<1> > ("b27_vlog");
        m_dut_vlog->b27(*b27_vlog);
        b28_vlog=new sc_signal<sc_lv<1> > ("b28_vlog");
        m_dut_vlog->b28(*b28_vlog);
        b29_vlog=new sc_signal<sc_lv<1> > ("b29_vlog");
        m_dut_vlog->b29(*b29_vlog);
        b30_vlog=new sc_signal<sc_lv<1> > ("b30_vlog");
        m_dut_vlog->b30(*b30_vlog);
        b31_vlog=new sc_signal<sc_lv<1> > ("b31_vlog");
        m_dut_vlog->b31(*b31_vlog);
        w_flag_vlog_dut=new sc_signal<sc_lv<1> > ("w_flag_vlog_dut");
        m_dut_vlog->w_flag(*w_flag_vlog_dut);
        s0_vlog_dut=new sc_signal<sc_lv<1> > ("s0_vlog_dut");
        m_dut_vlog->s0(*s0_vlog_dut);
        s1_vlog_dut=new sc_signal<sc_lv<1> > ("s1_vlog_dut");
        m_dut_vlog->s1(*s1_vlog_dut);
        s2_vlog_dut=new sc_signal<sc_lv<1> > ("s2_vlog_dut");
        m_dut_vlog->s2(*s2_vlog_dut);
        s3_vlog_dut=new sc_signal<sc_lv<1> > ("s3_vlog_dut");
        m_dut_vlog->s3(*s3_vlog_dut);
        s4_vlog_dut=new sc_signal<sc_lv<1> > ("s4_vlog_dut");
        m_dut_vlog->s4(*s4_vlog_dut);
        s5_vlog_dut=new sc_signal<sc_lv<1> > ("s5_vlog_dut");
        m_dut_vlog->s5(*s5_vlog_dut);
        s6_vlog_dut=new sc_signal<sc_lv<1> > ("s6_vlog_dut");
        m_dut_vlog->s6(*s6_vlog_dut);
        s7_vlog_dut=new sc_signal<sc_lv<1> > ("s7_vlog_dut");
        m_dut_vlog->s7(*s7_vlog_dut);
        s8_vlog_dut=new sc_signal<sc_lv<1> > ("s8_vlog_dut");
        m_dut_vlog->s8(*s8_vlog_dut);
        s9_vlog_dut=new sc_signal<sc_lv<1> > ("s9_vlog_dut");
        m_dut_vlog->s9(*s9_vlog_dut);
        s10_vlog_dut=new sc_signal<sc_lv<1> > ("s10_vlog_dut");
        m_dut_vlog->s10(*s10_vlog_dut);
        s11_vlog_dut=new sc_signal<sc_lv<1> > ("s11_vlog_dut");
        m_dut_vlog->s11(*s11_vlog_dut);
        s12_vlog_dut=new sc_signal<sc_lv<1> > ("s12_vlog_dut");
        m_dut_vlog->s12(*s12_vlog_dut);
        s13_vlog_dut=new sc_signal<sc_lv<1> > ("s13_vlog_dut");
        m_dut_vlog->s13(*s13_vlog_dut);
        s14_vlog_dut=new sc_signal<sc_lv<1> > ("s14_vlog_dut");
        m_dut_vlog->s14(*s14_vlog_dut);
        s15_vlog_dut=new sc_signal<sc_lv<1> > ("s15_vlog_dut");
        m_dut_vlog->s15(*s15_vlog_dut);
        s16_vlog_dut=new sc_signal<sc_lv<1> > ("s16_vlog_dut");
        m_dut_vlog->s16(*s16_vlog_dut);
        s17_vlog_dut=new sc_signal<sc_lv<1> > ("s17_vlog_dut");
        m_dut_vlog->s17(*s17_vlog_dut);
        s18_vlog_dut=new sc_signal<sc_lv<1> > ("s18_vlog_dut");
        m_dut_vlog->s18(*s18_vlog_dut);
        s19_vlog_dut=new sc_signal<sc_lv<1> > ("s19_vlog_dut");
        m_dut_vlog->s19(*s19_vlog_dut);
        s20_vlog_dut=new sc_signal<sc_lv<1> > ("s20_vlog_dut");
        m_dut_vlog->s20(*s20_vlog_dut);
        s21_vlog_dut=new sc_signal<sc_lv<1> > ("s21_vlog_dut");
        m_dut_vlog->s21(*s21_vlog_dut);
        s22_vlog_dut=new sc_signal<sc_lv<1> > ("s22_vlog_dut");
        m_dut_vlog->s22(*s22_vlog_dut);
        s23_vlog_dut=new sc_signal<sc_lv<1> > ("s23_vlog_dut");
        m_dut_vlog->s23(*s23_vlog_dut);
        s24_vlog_dut=new sc_signal<sc_lv<1> > ("s24_vlog_dut");
        m_dut_vlog->s24(*s24_vlog_dut);
        s25_vlog_dut=new sc_signal<sc_lv<1> > ("s25_vlog_dut");
        m_dut_vlog->s25(*s25_vlog_dut);
        s26_vlog_dut=new sc_signal<sc_lv<1> > ("s26_vlog_dut");
        m_dut_vlog->s26(*s26_vlog_dut);
        s27_vlog_dut=new sc_signal<sc_lv<1> > ("s27_vlog_dut");
        m_dut_vlog->s27(*s27_vlog_dut);
        s28_vlog_dut=new sc_signal<sc_lv<1> > ("s28_vlog_dut");
        m_dut_vlog->s28(*s28_vlog_dut);
        s29_vlog_dut=new sc_signal<sc_lv<1> > ("s29_vlog_dut");
        m_dut_vlog->s29(*s29_vlog_dut);
        s30_vlog_dut=new sc_signal<sc_lv<1> > ("s30_vlog_dut");
        m_dut_vlog->s30(*s30_vlog_dut);
        s31_vlog_dut=new sc_signal<sc_lv<1> > ("s31_vlog_dut");
        m_dut_vlog->s31(*s31_vlog_dut);
        cout_vlog_dut=new sc_signal<sc_lv<1> > ("cout_vlog_dut");
        m_dut_vlog->cout(*cout_vlog_dut);
        std::cout << "CtoS Verification Wrapper: Instantiating RTL module " << m_dut_vlog->hdl_name() << " as DUT" << std::endl;
        SC_METHOD(ctos_convert_input);
        sensitive << cin;
        SC_METHOD(ctos_convert_input_0);
        sensitive << pwr_sig;
        SC_METHOD(ctos_convert_input_1);
        sensitive << clk_gate;
        SC_METHOD(ctos_convert_input_2);
        sensitive << a0;
        SC_METHOD(ctos_convert_input_3);
        sensitive << a1;
        SC_METHOD(ctos_convert_input_4);
        sensitive << a2;
        SC_METHOD(ctos_convert_input_5);
        sensitive << a3;
        SC_METHOD(ctos_convert_input_6);
        sensitive << a4;
        SC_METHOD(ctos_convert_input_7);
        sensitive << a5;
        SC_METHOD(ctos_convert_input_8);
        sensitive << a6;
        SC_METHOD(ctos_convert_input_9);
        sensitive << a7;
        SC_METHOD(ctos_convert_input_10);
        sensitive << a8;
        SC_METHOD(ctos_convert_input_11);
        sensitive << a9;
        SC_METHOD(ctos_convert_input_12);
        sensitive << a10;
        SC_METHOD(ctos_convert_input_13);
        sensitive << a11;
        SC_METHOD(ctos_convert_input_14);
        sensitive << a12;
        SC_METHOD(ctos_convert_input_15);
        sensitive << a13;
        SC_METHOD(ctos_convert_input_16);
        sensitive << a14;
        SC_METHOD(ctos_convert_input_17);
        sensitive << a15;
        SC_METHOD(ctos_convert_input_18);
        sensitive << b0;
        SC_METHOD(ctos_convert_input_19);
        sensitive << b1;
        SC_METHOD(ctos_convert_input_20);
        sensitive << b2;
        SC_METHOD(ctos_convert_input_21);
        sensitive << b3;
        SC_METHOD(ctos_convert_input_22);
        sensitive << b4;
        SC_METHOD(ctos_convert_input_23);
        sensitive << b5;
        SC_METHOD(ctos_convert_input_24);
        sensitive << b6;
        SC_METHOD(ctos_convert_input_25);
        sensitive << b7;
        SC_METHOD(ctos_convert_input_26);
        sensitive << b8;
        SC_METHOD(ctos_convert_input_27);
        sensitive << b9;
        SC_METHOD(ctos_convert_input_28);
        sensitive << b10;
        SC_METHOD(ctos_convert_input_29);
        sensitive << b11;
        SC_METHOD(ctos_convert_input_30);
        sensitive << b12;
        SC_METHOD(ctos_convert_input_31);
        sensitive << b13;
        SC_METHOD(ctos_convert_input_32);
        sensitive << b14;
        SC_METHOD(ctos_convert_input_33);
        sensitive << b15;
        SC_METHOD(ctos_convert_input_34);
        sensitive << a16;
        SC_METHOD(ctos_convert_input_35);
        sensitive << a17;
        SC_METHOD(ctos_convert_input_36);
        sensitive << a18;
        SC_METHOD(ctos_convert_input_37);
        sensitive << a19;
        SC_METHOD(ctos_convert_input_38);
        sensitive << a20;
        SC_METHOD(ctos_convert_input_39);
        sensitive << a21;
        SC_METHOD(ctos_convert_input_40);
        sensitive << a22;
        SC_METHOD(ctos_convert_input_41);
        sensitive << a23;
        SC_METHOD(ctos_convert_input_42);
        sensitive << a24;
        SC_METHOD(ctos_convert_input_43);
        sensitive << a25;
        SC_METHOD(ctos_convert_input_44);
        sensitive << a26;
        SC_METHOD(ctos_convert_input_45);
        sensitive << a27;
        SC_METHOD(ctos_convert_input_46);
        sensitive << a28;
        SC_METHOD(ctos_convert_input_47);
        sensitive << a29;
        SC_METHOD(ctos_convert_input_48);
        sensitive << a30;
        SC_METHOD(ctos_convert_input_49);
        sensitive << a31;
        SC_METHOD(ctos_convert_input_50);
        sensitive << b16;
        SC_METHOD(ctos_convert_input_51);
        sensitive << b17;
        SC_METHOD(ctos_convert_input_52);
        sensitive << b18;
        SC_METHOD(ctos_convert_input_53);
        sensitive << b19;
        SC_METHOD(ctos_convert_input_54);
        sensitive << b20;
        SC_METHOD(ctos_convert_input_55);
        sensitive << b21;
        SC_METHOD(ctos_convert_input_56);
        sensitive << b22;
        SC_METHOD(ctos_convert_input_57);
        sensitive << b23;
        SC_METHOD(ctos_convert_input_58);
        sensitive << b24;
        SC_METHOD(ctos_convert_input_59);
        sensitive << b25;
        SC_METHOD(ctos_convert_input_60);
        sensitive << b26;
        SC_METHOD(ctos_convert_input_61);
        sensitive << b27;
        SC_METHOD(ctos_convert_input_62);
        sensitive << b28;
        SC_METHOD(ctos_convert_input_63);
        sensitive << b29;
        SC_METHOD(ctos_convert_input_64);
        sensitive << b30;
        SC_METHOD(ctos_convert_input_65);
        sensitive << b31;
        SC_METHOD(ctos_convert_output);
        dont_initialize();
        sensitive << *w_flag_vlog_dut;
        SC_METHOD(ctos_convert_output_0);
        dont_initialize();
        sensitive << *s0_vlog_dut;
        SC_METHOD(ctos_convert_output_1);
        dont_initialize();
        sensitive << *s1_vlog_dut;
        SC_METHOD(ctos_convert_output_2);
        dont_initialize();
        sensitive << *s2_vlog_dut;
        SC_METHOD(ctos_convert_output_3);
        dont_initialize();
        sensitive << *s3_vlog_dut;
        SC_METHOD(ctos_convert_output_4);
        dont_initialize();
        sensitive << *s4_vlog_dut;
        SC_METHOD(ctos_convert_output_5);
        dont_initialize();
        sensitive << *s5_vlog_dut;
        SC_METHOD(ctos_convert_output_6);
        dont_initialize();
        sensitive << *s6_vlog_dut;
        SC_METHOD(ctos_convert_output_7);
        dont_initialize();
        sensitive << *s7_vlog_dut;
        SC_METHOD(ctos_convert_output_8);
        dont_initialize();
        sensitive << *s8_vlog_dut;
        SC_METHOD(ctos_convert_output_9);
        dont_initialize();
        sensitive << *s9_vlog_dut;
        SC_METHOD(ctos_convert_output_10);
        dont_initialize();
        sensitive << *s10_vlog_dut;
        SC_METHOD(ctos_convert_output_11);
        dont_initialize();
        sensitive << *s11_vlog_dut;
        SC_METHOD(ctos_convert_output_12);
        dont_initialize();
        sensitive << *s12_vlog_dut;
        SC_METHOD(ctos_convert_output_13);
        dont_initialize();
        sensitive << *s13_vlog_dut;
        SC_METHOD(ctos_convert_output_14);
        dont_initialize();
        sensitive << *s14_vlog_dut;
        SC_METHOD(ctos_convert_output_15);
        dont_initialize();
        sensitive << *s15_vlog_dut;
        SC_METHOD(ctos_convert_output_16);
        dont_initialize();
        sensitive << *s16_vlog_dut;
        SC_METHOD(ctos_convert_output_17);
        dont_initialize();
        sensitive << *s17_vlog_dut;
        SC_METHOD(ctos_convert_output_18);
        dont_initialize();
        sensitive << *s18_vlog_dut;
        SC_METHOD(ctos_convert_output_19);
        dont_initialize();
        sensitive << *s19_vlog_dut;
        SC_METHOD(ctos_convert_output_20);
        dont_initialize();
        sensitive << *s20_vlog_dut;
        SC_METHOD(ctos_convert_output_21);
        dont_initialize();
        sensitive << *s21_vlog_dut;
        SC_METHOD(ctos_convert_output_22);
        dont_initialize();
        sensitive << *s22_vlog_dut;
        SC_METHOD(ctos_convert_output_23);
        dont_initialize();
        sensitive << *s23_vlog_dut;
        SC_METHOD(ctos_convert_output_24);
        dont_initialize();
        sensitive << *s24_vlog_dut;
        SC_METHOD(ctos_convert_output_25);
        dont_initialize();
        sensitive << *s25_vlog_dut;
        SC_METHOD(ctos_convert_output_26);
        dont_initialize();
        sensitive << *s26_vlog_dut;
        SC_METHOD(ctos_convert_output_27);
        dont_initialize();
        sensitive << *s27_vlog_dut;
        SC_METHOD(ctos_convert_output_28);
        dont_initialize();
        sensitive << *s28_vlog_dut;
        SC_METHOD(ctos_convert_output_29);
        dont_initialize();
        sensitive << *s29_vlog_dut;
        SC_METHOD(ctos_convert_output_30);
        dont_initialize();
        sensitive << *s30_vlog_dut;
        SC_METHOD(ctos_convert_output_31);
        dont_initialize();
        sensitive << *s31_vlog_dut;
        SC_METHOD(ctos_convert_output_32);
        dont_initialize();
        sensitive << *cout_vlog_dut;
    }
};




    typedef RCA_32b_ctos_wrapper RCA_32b_ctos;
  #define RCA_32B_CTOS_INSTANCE(INSTNAME) RCA_32b_ctos(INSTNAME, CTOS_TARGET_SUFFIX(CTOS_MODEL), NULL, false)
  #define RCA_32B_CTOS_COMPARE_INSTANCE(INSTNAME, REFNAME) RCA_32b_ctos(INSTNAME, CTOS_TARGET_SUFFIX(CTOS_MODEL), REFNAME, true)
  #define RCA_32B_CTOS_RTL_ONLY_INSTANCE(INSTNAME) RCA_32b_ctos(INSTNAME, RCA_32b_ctos::SimulateRTLOnly)
#endif // ifdef RCA_32b_ctos_wrapper_P

